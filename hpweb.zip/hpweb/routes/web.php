<?php
/** @var Router $router */

// ===== FRONTEND =====

// Home
$router->get('/',          'HomeController', 'index');
$router->get('/tim-kiem',  'HomeController', 'search');

// Products
$router->get('/san-pham/{slug}',  'ProductController', 'category');
$router->get('/chi-tiet/{slug}',  'ProductController', 'detail');

// Cart
$router->get('/gio-hang',              'CartController', 'index');
$router->post('/gio-hang/them',        'CartController', 'add');
$router->post('/gio-hang/cap-nhat',    'CartController', 'update');
$router->get('/gio-hang/xoa',          'CartController', 'remove');
$router->get('/gio-hang/xoa-tat-ca',   'CartController', 'clear');

// Checkout
$router->get('/dat-hang',           'CheckoutController', 'index');
$router->post('/dat-hang/xu-ly',    'CheckoutController', 'process');
$router->get('/dat-hang/thanh-cong','CheckoutController', 'success');

// Auth
$router->get('/dang-nhap',        'AuthController', 'loginForm');
$router->post('/dang-nhap/xu-ly', 'AuthController', 'login');
$router->get('/dang-ky',          'AuthController', 'registerForm');
$router->post('/dang-ky/xu-ly',   'AuthController', 'register');
$router->get('/dang-xuat',        'AuthController', 'logout');
$router->get('/tai-khoan',        'AuthController', 'profile');
$router->post('/tai-khoan/cap-nhat', 'AuthController', 'updateProfile');

// Contact
$router->get('/lien-he',       'ContactController', 'index');
$router->post('/lien-he/gui',  'ContactController', 'send');

// ===== ADMIN =====

$router->get('/admin',                        'AdminController', 'index');

// Admin - Products
$router->get('/admin/san-pham',               'AdminController', 'products');
$router->get('/admin/san-pham/them',          'AdminController', 'productCreate');
$router->post('/admin/san-pham/luu',          'AdminController', 'productStore');
$router->get('/admin/san-pham/sua/{id}',      'AdminController', 'productEdit');
$router->post('/admin/san-pham/cap-nhat/{id}','AdminController', 'productUpdate');
$router->get('/admin/san-pham/xoa/{id}',      'AdminController', 'productDelete');

// Admin - Orders
$router->get('/admin/don-hang',                       'AdminController', 'orders');
$router->get('/admin/don-hang/{id}',                  'AdminController', 'orderDetail');
$router->post('/admin/don-hang/cap-nhat/{id}',        'AdminController', 'orderUpdateStatus');

// Admin - Categories
$router->get('/admin/danh-muc',          'AdminController', 'categories');
$router->post('/admin/danh-muc/luu',     'AdminController', 'categoryStore');
$router->get('/admin/danh-muc/xoa/{id}', 'AdminController', 'categoryDelete');

// Admin - Contacts
$router->get('/admin/lien-he', 'AdminController', 'contacts');

// Admin - Settings
$router->get('/admin/cai-dat',       'AdminController', 'settings');
$router->post('/admin/cai-dat/luu',  'AdminController', 'settingsUpdate');

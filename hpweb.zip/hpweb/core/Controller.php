<?php
abstract class Controller {
    protected array $data = [];

    protected function view(string $viewPath, array $data = []): void {
        $this->data = array_merge($this->data, $data);
        extract($this->data);

        $viewFile = __DIR__ . '/../app/Views/' . str_replace('.', '/', $viewPath) . '.php';
        if (!file_exists($viewFile)) {
            die("View không tồn tại: $viewFile");
        }

        // Render với layout nếu không phải AJAX
        if (!$this->isAjax()) {
            $layout = $this->data['layout'] ?? 'main';
            $layoutFile = __DIR__ . '/../app/Views/layouts/' . $layout . '.php';
            $content = $viewFile;
            if (file_exists($layoutFile)) {
                require $layoutFile;
            } else {
                require $viewFile;
            }
        } else {
            require $viewFile;
        }
    }

    protected function json(mixed $data, int $code = 200): void {
        http_response_code($code);
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode($data, JSON_UNESCAPED_UNICODE);
        exit;
    }

    protected function redirect(string $url): void {
        header("Location: $url");
        exit;
    }

    protected function isAjax(): bool {
        return isset($_SERVER['HTTP_X_REQUESTED_WITH'])
            && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest';
    }

    protected function requireAuth(): void {
        if (empty($_SESSION['user_id'])) {
            $this->redirect(APP_URL . '/auth/login');
        }
    }

    protected function requireAdmin(): void {
        if (empty($_SESSION['user_id']) || ($_SESSION['user_role'] ?? '') !== 'admin') {
            $this->redirect(APP_URL . '/');
        }
    }

    protected function sanitize(string $value): string {
        return htmlspecialchars(strip_tags(trim($value)), ENT_QUOTES, 'UTF-8');
    }

    protected function post(string $key, mixed $default = ''): mixed {
        return isset($_POST[$key]) ? trim($_POST[$key]) : $default;
    }

    protected function get(string $key, mixed $default = ''): mixed {
        return isset($_GET[$key]) ? trim($_GET[$key]) : $default;
    }

    protected function setFlash(string $type, string $message): void {
        $_SESSION['flash'] = ['type' => $type, 'message' => $message];
    }

    protected function getFlash(): ?array {
        $flash = $_SESSION['flash'] ?? null;
        unset($_SESSION['flash']);
        return $flash;
    }
}

<?php
abstract class Model {
    protected Database $db;
    protected string $table = '';
    protected string $primaryKey = 'id';

    public function __construct() {
        $this->db = Database::getInstance();
    }

    public function findAll(string $where = '', array $params = [], string $order = '', int $limit = 0, int $offset = 0): array {
        $sql = "SELECT * FROM `{$this->table}`";
        if ($where) $sql .= " WHERE $where";
        if ($order) $sql .= " ORDER BY $order";
        if ($limit)  $sql .= " LIMIT $limit";
        if ($offset) $sql .= " OFFSET $offset";
        return $this->db->query($sql, $params);
    }

    public function findOne(string $where, array $params = []): ?array {
        $sql = "SELECT * FROM `{$this->table}` WHERE $where LIMIT 1";
        return $this->db->queryOne($sql, $params);
    }

    public function findById(int $id): ?array {
        return $this->findOne("`{$this->primaryKey}` = ?", [$id]);
    }

    public function count(string $where = '', array $params = []): int {
        $sql = "SELECT COUNT(*) as cnt FROM `{$this->table}`";
        if ($where) $sql .= " WHERE $where";
        $row = $this->db->queryOne($sql, $params);
        return (int)($row['cnt'] ?? 0);
    }

    public function create(array $data): string {
        $cols   = implode(', ', array_map(fn($c) => "`$c`", array_keys($data)));
        $places = implode(', ', array_fill(0, count($data), '?'));
        $sql    = "INSERT INTO `{$this->table}` ($cols) VALUES ($places)";
        return $this->db->insert($sql, array_values($data));
    }

    public function update(int $id, array $data): int {
        $sets = implode(', ', array_map(fn($c) => "`$c` = ?", array_keys($data)));
        $sql  = "UPDATE `{$this->table}` SET $sets WHERE `{$this->primaryKey}` = ?";
        return $this->db->execute($sql, [...array_values($data), $id]);
    }

    public function delete(int $id): int {
        return $this->db->execute("DELETE FROM `{$this->table}` WHERE `{$this->primaryKey}` = ?", [$id]);
    }
}

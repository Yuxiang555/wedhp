<?php
class Router {
    private array $routes = [];

    public function add(string $method, string $pattern, string $controller, string $action): void {
        $this->routes[] = compact('method', 'pattern', 'controller', 'action');
    }

    public function get(string $pattern, string $controller, string $action): void {
        $this->add('GET', $pattern, $controller, $action);
    }

    public function post(string $pattern, string $controller, string $action): void {
        $this->add('POST', $pattern, $controller, $action);
    }

    public function dispatch(string $uri, string $method): void {
        // Xoá query string
        $uri = strtok($uri, '?');
        // Xoá base path
        $basePath = rtrim(dirname($_SERVER['SCRIPT_NAME']), '/');
        $uri = '/' . ltrim(substr($uri, strlen($basePath)), '/');
        if ($uri === '') $uri = '/';

        foreach ($this->routes as $route) {
            if (strtoupper($route['method']) !== strtoupper($method)) continue;

            $pattern = '@^' . preg_replace('/\{([a-zA-Z0-9_]+)\}/', '(?P<$1>[^/]+)', $route['pattern']) . '$@';
            if (preg_match($pattern, $uri, $matches)) {
                $params = array_filter($matches, 'is_string', ARRAY_FILTER_USE_KEY);

                $controllerClass = $route['controller'];
                $controllerFile  = __DIR__ . '/../app/Controllers/' . $controllerClass . '.php';
                if (!file_exists($controllerFile)) {
                    $this->notFound();
                    return;
                }
                require_once $controllerFile;
                $obj = new $controllerClass();
                $action = $route['action'];
                if (!method_exists($obj, $action)) {
                    $this->notFound();
                    return;
                }
                $obj->$action(...array_values($params));
                return;
            }
        }
        $this->notFound();
    }

    private function notFound(): void {
        http_response_code(404);
        require __DIR__ . '/../app/Views/errors/404.php';
    }
}

<?php
define('APP_NAME', 'Vi Tính Net - Kho Vi Tính Giá Nét');
define('APP_URL', 'http://localhost/hpweb');
define('APP_VERSION', '1.0.0');
define('DEFAULT_CONTROLLER', 'HomeController');
define('DEFAULT_METHOD', 'index');
define('ITEMS_PER_PAGE', 12);

// Session
define('SESSION_NAME', 'vitinhnet_session');

// Upload
define('UPLOAD_PATH', __DIR__ . '/../public/images/products/');
define('MAX_FILE_SIZE', 5 * 1024 * 1024); // 5MB

<?php
class HomeController extends Controller {
    private ProductModel $productModel;
    private CategoryModel $categoryModel;
    private BannerModel $bannerModel;

    public function __construct() {
        $this->productModel  = new ProductModel();
        $this->categoryModel = new CategoryModel();
        $this->bannerModel   = new BannerModel();
    }

    public function index(): void {
        $banners        = $this->bannerModel->getActive();
        $categories     = $this->categoryModel->getWithCount();
        $featuredProducts = $this->productModel->getFeatured(8);
        $newProducts    = $this->productModel->getNew(8);

        $this->view('home.index', [
            'title'           => APP_NAME,
            'banners'         => $banners,
            'categories'      => $categories,
            'featuredProducts'=> $featuredProducts,
            'newProducts'     => $newProducts,
        ]);
    }

    public function search(): void {
        $keyword = $this->get('q');
        $page    = max(1, (int)$this->get('page', 1));
        $limit   = ITEMS_PER_PAGE;
        $offset  = ($page - 1) * $limit;

        $products   = [];
        $totalItems = 0;

        if ($keyword !== '') {
            $products   = $this->productModel->search($keyword, $limit, $offset);
            $totalItems = $this->productModel->countSearch($keyword);
        }

        $totalPages = $totalItems > 0 ? ceil($totalItems / $limit) : 1;

        $this->view('home.search', [
            'title'      => 'Tìm kiếm: ' . htmlspecialchars($keyword),
            'keyword'    => $keyword,
            'products'   => $products,
            'totalItems' => $totalItems,
            'totalPages' => $totalPages,
            'page'       => $page,
        ]);
    }
}

<?php
class AdminController extends Controller {
    private ProductModel $productModel;
    private CategoryModel $categoryModel;
    private OrderModel $orderModel;
    private ContactModel $contactModel;
    private SettingModel $settingModel;

    public function __construct() {
        $this->requireAdmin();
        $this->productModel  = new ProductModel();
        $this->categoryModel = new CategoryModel();
        $this->orderModel    = new OrderModel();
        $this->contactModel  = new ContactModel();
        $this->settingModel  = new SettingModel();
    }

    // ===== DASHBOARD =====
    public function index(): void {
        $stats          = $this->orderModel->getStats();
        $totalProducts  = $this->productModel->count();
        $totalCategories= $this->categoryModel->count();
        $unreadContacts = $this->contactModel->getUnread();
        $recentOrders   = $this->orderModel->getAllAdmin('', 10, 0);

        $this->view('admin.dashboard', [
            'title'          => 'Quản trị - ' . APP_NAME,
            'layout'         => 'admin',
            'stats'          => $stats,
            'totalProducts'  => $totalProducts,
            'totalCategories'=> $totalCategories,
            'unreadContacts' => $unreadContacts,
            'recentOrders'   => $recentOrders,
        ]);
    }

    // ===== PRODUCTS =====
    public function products(): void {
        $search = $this->get('search');
        $page   = max(1, (int)$this->get('page', 1));
        $limit  = 20;
        $offset = ($page - 1) * $limit;

        $products   = $this->productModel->getAllAdmin($search, $limit, $offset);
        $totalItems = $this->productModel->count($search ? "name LIKE ? OR sku LIKE ?" : '', $search ? ['%'.$search.'%','%'.$search.'%'] : []);
        $totalPages = max(1, ceil($totalItems / $limit));
        $categories = $this->categoryModel->getAll();
        $flash      = $this->getFlash();

        $this->view('admin.products.index', [
            'title'      => 'Quản lý sản phẩm',
            'layout'     => 'admin',
            'products'   => $products,
            'categories' => $categories,
            'totalItems' => $totalItems,
            'totalPages' => $totalPages,
            'page'       => $page,
            'search'     => $search,
            'flash'      => $flash,
        ]);
    }

    public function productCreate(): void {
        $categories = $this->categoryModel->getAll();
        $this->view('admin.products.create', [
            'title'      => 'Thêm sản phẩm',
            'layout'     => 'admin',
            'categories' => $categories,
            'flash'      => $this->getFlash(),
        ]);
    }

    public function productStore(): void {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            $this->redirect(APP_URL . '/admin/san-pham/them');
        }

        $data = [
            'category_id' => (int)$this->post('category_id'),
            'name'        => $this->sanitize($this->post('name')),
            'slug'        => $this->makeSlug($this->post('name')),
            'sku'         => $this->sanitize($this->post('sku')),
            'description' => $this->post('description'),
            'specs'       => $this->post('specs'),
            'price'       => (int)str_replace(['.', ','], '', $this->post('price')),
            'sale_price'  => (int)str_replace(['.', ','], '', $this->post('sale_price')) ?: null,
            'stock'       => (int)$this->post('stock'),
            'is_featured' => $this->post('is_featured') ? 1 : 0,
            'is_new'      => $this->post('is_new') ? 1 : 0,
            'status'      => (int)$this->post('status', 1),
        ];

        // Xử lý upload ảnh
        if (!empty($_FILES['image']['name'])) {
            $imageName = $this->uploadImage($_FILES['image']);
            if ($imageName) $data['image'] = $imageName;
        }

        $this->productModel->create($data);
        $this->setFlash('success', 'Thêm sản phẩm thành công!');
        $this->redirect(APP_URL . '/admin/san-pham');
    }

    public function productEdit(string $id): void {
        $product    = $this->productModel->findById((int)$id);
        $categories = $this->categoryModel->getAll();
        if (!$product) { $this->redirect(APP_URL . '/admin/san-pham'); }

        $this->view('admin.products.edit', [
            'title'      => 'Sửa sản phẩm',
            'layout'     => 'admin',
            'product'    => $product,
            'categories' => $categories,
            'flash'      => $this->getFlash(),
        ]);
    }

    public function productUpdate(string $id): void {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            $this->redirect(APP_URL . '/admin/san-pham');
        }

        $data = [
            'category_id' => (int)$this->post('category_id'),
            'name'        => $this->sanitize($this->post('name')),
            'sku'         => $this->sanitize($this->post('sku')),
            'description' => $this->post('description'),
            'specs'       => $this->post('specs'),
            'price'       => (int)str_replace(['.', ','], '', $this->post('price')),
            'sale_price'  => (int)str_replace(['.', ','], '', $this->post('sale_price')) ?: null,
            'stock'       => (int)$this->post('stock'),
            'is_featured' => $this->post('is_featured') ? 1 : 0,
            'is_new'      => $this->post('is_new') ? 1 : 0,
            'status'      => (int)$this->post('status', 1),
        ];

        if (!empty($_FILES['image']['name'])) {
            $imageName = $this->uploadImage($_FILES['image']);
            if ($imageName) $data['image'] = $imageName;
        }

        $this->productModel->update((int)$id, $data);
        $this->setFlash('success', 'Cập nhật sản phẩm thành công!');
        $this->redirect(APP_URL . '/admin/san-pham');
    }

    public function productDelete(string $id): void {
        $this->productModel->delete((int)$id);
        $this->setFlash('success', 'Đã xóa sản phẩm');
        $this->redirect(APP_URL . '/admin/san-pham');
    }

    // ===== ORDERS =====
    public function orders(): void {
        $status = $this->get('status');
        $page   = max(1, (int)$this->get('page', 1));
        $limit  = 20;
        $offset = ($page - 1) * $limit;

        $orders     = $this->orderModel->getAllAdmin($status, $limit, $offset);
        $totalItems = $this->orderModel->count($status ? 'status = ?' : '', $status ? [$status] : []);
        $totalPages = max(1, ceil($totalItems / $limit));

        $this->view('admin.orders.index', [
            'title'      => 'Quản lý đơn hàng',
            'layout'     => 'admin',
            'orders'     => $orders,
            'totalItems' => $totalItems,
            'totalPages' => $totalPages,
            'page'       => $page,
            'status'     => $status,
            'flash'      => $this->getFlash(),
        ]);
    }

    public function orderDetail(string $id): void {
        $order = $this->orderModel->getWithItems((int)$id);
        if (!$order) { $this->redirect(APP_URL . '/admin/don-hang'); }

        $this->view('admin.orders.detail', [
            'title'  => 'Chi tiết đơn hàng #' . $order['order_code'],
            'layout' => 'admin',
            'order'  => $order,
            'flash'  => $this->getFlash(),
        ]);
    }

    public function orderUpdateStatus(string $id): void {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            $this->redirect(APP_URL . '/admin/don-hang');
        }
        $status = $this->post('status');
        $allowed = ['pending', 'confirmed', 'shipping', 'delivered', 'cancelled'];
        if (in_array($status, $allowed)) {
            $this->orderModel->updateStatus((int)$id, $status);
            $this->setFlash('success', 'Cập nhật trạng thái đơn hàng thành công');
        }
        $this->redirect(APP_URL . '/admin/don-hang/' . $id);
    }

    // ===== CATEGORIES =====
    public function categories(): void {
        $categories = $this->categoryModel->getWithCount();
        $this->view('admin.categories.index', [
            'title'      => 'Quản lý danh mục',
            'layout'     => 'admin',
            'categories' => $categories,
            'flash'      => $this->getFlash(),
        ]);
    }

    public function categoryStore(): void {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            $this->redirect(APP_URL . '/admin/danh-muc');
        }
        $name = $this->sanitize($this->post('name'));
        $this->categoryModel->create([
            'name'   => $name,
            'slug'   => $this->makeSlug($name),
            'icon'   => $this->sanitize($this->post('icon')),
            'sort_order' => (int)$this->post('sort_order', 0),
            'status' => 1,
        ]);
        $this->setFlash('success', 'Thêm danh mục thành công');
        $this->redirect(APP_URL . '/admin/danh-muc');
    }

    public function categoryDelete(string $id): void {
        $this->categoryModel->delete((int)$id);
        $this->setFlash('success', 'Đã xóa danh mục');
        $this->redirect(APP_URL . '/admin/danh-muc');
    }

    // ===== CONTACTS =====
    public function contacts(): void {
        $contacts = $this->contactModel->findAll('', [], 'created_at DESC');
        // Đánh dấu tất cả đã đọc
        $this->contactModel->db->execute("UPDATE contacts SET is_read = 1");
        $this->view('admin.contacts', [
            'title'    => 'Tin nhắn liên hệ',
            'layout'   => 'admin',
            'contacts' => $contacts,
        ]);
    }

    // ===== SETTINGS =====
    public function settings(): void {
        $settings = $this->settingModel->getAll();
        $this->view('admin.settings', [
            'title'    => 'Cài đặt website',
            'layout'   => 'admin',
            'settings' => $settings,
            'flash'    => $this->getFlash(),
        ]);
    }

    public function settingsUpdate(): void {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            $this->redirect(APP_URL . '/admin/cai-dat');
        }
        $fields = ['site_name', 'site_phone', 'site_zalo', 'site_email', 'site_address', 'site_hours', 'site_facebook'];
        foreach ($fields as $field) {
            $this->settingModel->set($field, $this->sanitize($this->post($field)));
        }
        $this->setFlash('success', 'Lưu cài đặt thành công!');
        $this->redirect(APP_URL . '/admin/cai-dat');
    }

    // ===== HELPERS =====
    private function makeSlug(string $text): string {
        $text = mb_strtolower(trim($text));
        $map  = ['à'=>'a','á'=>'a','â'=>'a','ã'=>'a','ä'=>'a','å'=>'a',
                 'è'=>'e','é'=>'e','ê'=>'e','ë'=>'e','ì'=>'i','í'=>'i',
                 'î'=>'i','ï'=>'i','ò'=>'o','ó'=>'o','ô'=>'o','õ'=>'o',
                 'ö'=>'o','ù'=>'u','ú'=>'u','û'=>'u','ü'=>'u','ý'=>'y',
                 'đ'=>'d','ă'=>'a','ắ'=>'a','ặ'=>'a','ầ'=>'a','ấ'=>'a',
                 'ậ'=>'a','ằ'=>'a','ẳ'=>'a','ẵ'=>'a','ả'=>'a','ã'=>'a',
                 'ạ'=>'a','ề'=>'e','ế'=>'e','ệ'=>'e','ể'=>'e','ễ'=>'e',
                 'ẹ'=>'e','ẻ'=>'e','ị'=>'i','ỉ'=>'i','ĩ'=>'i','ờ'=>'o',
                 'ớ'=>'o','ợ'=>'o','ổ'=>'o','ỗ'=>'o','ộ'=>'o','ọ'=>'o',
                 'ỏ'=>'o','ơ'=>'o','ừ'=>'u','ứ'=>'u','ự'=>'u','ử'=>'u',
                 'ữ'=>'u','ụ'=>'u','ủ'=>'u','ũ'=>'u','ư'=>'u','ỳ'=>'y',
                 'ỵ'=>'y','ỷ'=>'y','ỹ'=>'y'];
        $text = strtr($text, $map);
        $text = preg_replace('/[^a-z0-9\s-]/', '', $text);
        $text = preg_replace('/[\s-]+/', '-', $text);
        return trim($text, '-') . '-' . substr(md5(uniqid()), 0, 5);
    }

    private function uploadImage(array $file): ?string {
        $allowed = ['image/jpeg','image/png','image/webp','image/gif'];
        if (!in_array($file['type'], $allowed)) return null;
        if ($file['size'] > MAX_FILE_SIZE) return null;

        $ext  = pathinfo($file['name'], PATHINFO_EXTENSION);
        $name = uniqid('product_') . '.' . $ext;
        $dest = UPLOAD_PATH . $name;

        if (!is_dir(UPLOAD_PATH)) mkdir(UPLOAD_PATH, 0755, true);
        if (move_uploaded_file($file['tmp_name'], $dest)) return $name;
        return null;
    }
}

<?php
class CheckoutController extends Controller {
    private ProductModel $productModel;
    private OrderModel $orderModel;
    private SettingModel $settingModel;

    public function __construct() {
        $this->productModel  = new ProductModel();
        $this->orderModel    = new OrderModel();
        $this->settingModel  = new SettingModel();
    }

    public function index(): void {
        $cart = $_SESSION['cart'] ?? [];
        if (empty($cart)) {
            $this->redirect(APP_URL . '/gio-hang');
        }

        $items = $this->buildCartItems($cart);
        $total = array_sum(array_column($items, 'subtotal'));
        $settings = $this->settingModel->getAll();

        $user = null;
        if (!empty($_SESSION['user_id'])) {
            $userModel = new UserModel();
            $user = $userModel->findById($_SESSION['user_id']);
        }

        $this->view('checkout.index', [
            'title'    => 'Thanh toán - ' . APP_NAME,
            'items'    => $items,
            'total'    => $total,
            'user'     => $user,
            'settings' => $settings,
        ]);
    }

    public function process(): void {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            $this->redirect(APP_URL . '/dat-hang');
        }

        $cart = $_SESSION['cart'] ?? [];
        if (empty($cart)) {
            $this->redirect(APP_URL . '/gio-hang');
        }

        // Validate
        $name    = trim($this->post('customer_name'));
        $phone   = trim($this->post('customer_phone'));
        $email   = trim($this->post('customer_email'));
        $address = trim($this->post('shipping_address'));
        $note    = trim($this->post('note'));
        $payment = in_array($this->post('payment_method'), ['cod', 'bank_transfer'])
                   ? $this->post('payment_method') : 'cod';

        $errors = [];
        if (!$name)    $errors[] = 'Vui lòng nhập họ tên';
        if (!$phone)   $errors[] = 'Vui lòng nhập số điện thoại';
        if (!$address) $errors[] = 'Vui lòng nhập địa chỉ';
        if (!preg_match('/^[0-9]{9,11}$/', $phone)) $errors[] = 'Số điện thoại không hợp lệ';

        if ($errors) {
            $this->setFlash('error', implode('<br>', $errors));
            $this->redirect(APP_URL . '/dat-hang');
        }

        $items    = $this->buildCartItems($cart);
        $total    = array_sum(array_column($items, 'subtotal'));
        $code     = $this->orderModel->generateCode();

        $orderData = [
            'user_id'          => $_SESSION['user_id'] ?? null,
            'order_code'       => $code,
            'customer_name'    => $name,
            'customer_phone'   => $phone,
            'customer_email'   => $email,
            'shipping_address' => $address,
            'note'             => $note,
            'total_amount'     => $total,
            'payment_method'   => $payment,
        ];

        $orderItems = array_map(fn($item) => [
            'product_id'    => $item['product']['id'],
            'product_name'  => $item['product']['name'],
            'product_image' => $item['product']['image'] ?? '',
            'price'         => $item['price'],
            'quantity'      => $item['quantity'],
            'subtotal'      => $item['subtotal'],
        ], $items);

        try {
            $this->orderModel->createOrder($orderData, $orderItems);
            $_SESSION['cart'] = [];
            $_SESSION['last_order_code'] = $code;
            $this->redirect(APP_URL . '/dat-hang/thanh-cong');
        } catch (Exception $e) {
            $this->setFlash('error', 'Có lỗi xảy ra, vui lòng thử lại!');
            $this->redirect(APP_URL . '/dat-hang');
        }
    }

    public function success(): void {
        $code  = $_SESSION['last_order_code'] ?? '';
        $order = null;
        if ($code) {
            $order = $this->orderModel->getByCode($code);
        }
        unset($_SESSION['last_order_code']);

        $this->view('checkout.success', [
            'title' => 'Đặt hàng thành công - ' . APP_NAME,
            'order' => $order,
        ]);
    }

    private function buildCartItems(array $cart): array {
        $items = [];
        foreach ($cart as $productId => $qty) {
            $product = $this->productModel->findById((int)$productId);
            if (!$product) continue;
            $price   = $product['sale_price'] ?: $product['price'];
            $items[] = [
                'product'  => $product,
                'quantity' => $qty,
                'price'    => $price,
                'subtotal' => $price * $qty,
            ];
        }
        return $items;
    }
}

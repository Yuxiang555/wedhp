<?php
class ContactController extends Controller {
    private ContactModel $contactModel;
    private SettingModel $settingModel;

    public function __construct() {
        $this->contactModel = new ContactModel();
        $this->settingModel = new SettingModel();
    }

    public function index(): void {
        $flash    = $this->getFlash();
        $settings = $this->settingModel->getAll();

        $this->view('contact.index', [
            'title'    => 'Liên hệ - ' . APP_NAME,
            'flash'    => $flash,
            'settings' => $settings,
        ]);
    }

    public function send(): void {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            $this->redirect(APP_URL . '/lien-he');
        }

        $name    = trim($this->post('name'));
        $phone   = trim($this->post('phone'));
        $email   = trim($this->post('email'));
        $subject = trim($this->post('subject'));
        $message = trim($this->post('message'));

        if (!$name || !$message) {
            $this->setFlash('error', 'Vui lòng nhập họ tên và nội dung tin nhắn');
            $this->redirect(APP_URL . '/lien-he');
        }

        $this->contactModel->create([
            'name'    => $this->sanitize($name),
            'phone'   => $this->sanitize($phone),
            'email'   => $this->sanitize($email),
            'subject' => $this->sanitize($subject),
            'message' => $this->sanitize($message),
        ]);

        $this->setFlash('success', 'Cảm ơn bạn đã liên hệ! Chúng tôi sẽ phản hồi sớm nhất.');
        $this->redirect(APP_URL . '/lien-he');
    }
}

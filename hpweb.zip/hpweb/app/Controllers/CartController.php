<?php
class CartController extends Controller {
    private ProductModel $productModel;

    public function __construct() {
        $this->productModel = new ProductModel();
    }

    public function index(): void {
        $cart  = $_SESSION['cart'] ?? [];
        $items = $this->buildCartItems($cart);
        $total = array_sum(array_column($items, 'subtotal'));

        $this->view('cart.index', [
            'title' => 'Giỏ hàng - ' . APP_NAME,
            'items' => $items,
            'total' => $total,
        ]);
    }

    public function add(): void {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            $this->redirect(APP_URL . '/gio-hang');
        }

        $productId = (int)$this->post('product_id');
        $qty       = max(1, (int)$this->post('quantity', 1));

        $product = $this->productModel->findById($productId);
        if (!$product || $product['status'] != 1) {
            if ($this->isAjax()) {
                $this->json(['success' => false, 'message' => 'Sản phẩm không tồn tại']);
            }
            $this->setFlash('error', 'Sản phẩm không tồn tại');
            $this->redirect(APP_URL . '/gio-hang');
        }

        if (!isset($_SESSION['cart'])) $_SESSION['cart'] = [];
        $cart = &$_SESSION['cart'];

        if (isset($cart[$productId])) {
            $cart[$productId] = min($cart[$productId] + $qty, $product['stock']);
        } else {
            $cart[$productId] = min($qty, $product['stock']);
        }

        $count = array_sum($cart);

        if ($this->isAjax()) {
            $this->json([
                'success' => true,
                'message' => 'Đã thêm vào giỏ hàng',
                'cart_count' => $count,
            ]);
        }

        $this->setFlash('success', 'Đã thêm "' . $product['name'] . '" vào giỏ hàng!');
        $this->redirect(APP_URL . '/gio-hang');
    }

    public function update(): void {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            $this->redirect(APP_URL . '/gio-hang');
        }

        $quantities = $_POST['quantity'] ?? [];
        if (!isset($_SESSION['cart'])) $_SESSION['cart'] = [];

        foreach ($quantities as $productId => $qty) {
            $productId = (int)$productId;
            $qty       = (int)$qty;
            if ($qty <= 0) {
                unset($_SESSION['cart'][$productId]);
            } else {
                $product = $this->productModel->findById($productId);
                if ($product) {
                    $_SESSION['cart'][$productId] = min($qty, $product['stock']);
                }
            }
        }

        $this->setFlash('success', 'Giỏ hàng đã được cập nhật');
        $this->redirect(APP_URL . '/gio-hang');
    }

    public function remove(): void {
        $productId = (int)$this->get('id');
        unset($_SESSION['cart'][$productId]);

        if ($this->isAjax()) {
            $cart  = $_SESSION['cart'] ?? [];
            $items = $this->buildCartItems($cart);
            $total = array_sum(array_column($items, 'subtotal'));
            $this->json([
                'success'    => true,
                'cart_count' => array_sum($cart),
                'total'      => number_format($total, 0, ',', '.') . 'đ',
            ]);
        }

        $this->setFlash('success', 'Đã xóa sản phẩm khỏi giỏ hàng');
        $this->redirect(APP_URL . '/gio-hang');
    }

    public function clear(): void {
        $_SESSION['cart'] = [];
        $this->redirect(APP_URL . '/gio-hang');
    }

    private function buildCartItems(array $cart): array {
        $items = [];
        foreach ($cart as $productId => $qty) {
            $product = $this->productModel->findById((int)$productId);
            if (!$product) continue;
            $price     = $product['sale_price'] ?: $product['price'];
            $items[]   = [
                'product'  => $product,
                'quantity' => $qty,
                'price'    => $price,
                'subtotal' => $price * $qty,
            ];
        }
        return $items;
    }
}

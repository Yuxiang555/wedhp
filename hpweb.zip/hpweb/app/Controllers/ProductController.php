<?php
class ProductController extends Controller {
    private ProductModel $productModel;
    private CategoryModel $categoryModel;

    public function __construct() {
        $this->productModel  = new ProductModel();
        $this->categoryModel = new CategoryModel();
    }

    // /san-pham/{slug-danh-muc}
    public function category(string $slug): void {
        $category = $this->categoryModel->getBySlug($slug);
        if (!$category) {
            http_response_code(404);
            $this->view('errors.404', ['title' => 'Không tìm thấy']);
            return;
        }

        $page       = max(1, (int)$this->get('page', 1));
        $sort       = $this->get('sort', 'newest');
        $limit      = ITEMS_PER_PAGE;
        $offset     = ($page - 1) * $limit;
        $totalItems = $this->productModel->countByCategory($category['id']);
        $totalPages = max(1, ceil($totalItems / $limit));
        $products   = $this->productModel->getByCategory($category['id'], $limit, $offset);
        $categories = $this->categoryModel->getWithCount();

        $this->view('products.category', [
            'title'      => $category['name'] . ' - ' . APP_NAME,
            'category'   => $category,
            'categories' => $categories,
            'products'   => $products,
            'totalItems' => $totalItems,
            'totalPages' => $totalPages,
            'page'       => $page,
            'sort'       => $sort,
        ]);
    }

    // /chi-tiet/{slug}
    public function detail(string $slug): void {
        $product = $this->productModel->getBySlug($slug);
        if (!$product) {
            http_response_code(404);
            $this->view('errors.404', ['title' => 'Không tìm thấy sản phẩm']);
            return;
        }

        $this->productModel->incrementView($product['id']);

        $related    = $this->productModel->getRelated($product['category_id'], $product['id'], 4);
        $categories = $this->categoryModel->getAll();

        // Parse images JSON
        $images = [];
        if (!empty($product['images'])) {
            $images = json_decode($product['images'], true) ?? [];
        }
        if (!empty($product['image'])) {
            array_unshift($images, $product['image']);
            $images = array_unique($images);
        }

        $this->view('products.detail', [
            'title'    => $product['name'] . ' - ' . APP_NAME,
            'product'  => $product,
            'images'   => $images,
            'related'  => $related,
            'categories' => $categories,
        ]);
    }
}

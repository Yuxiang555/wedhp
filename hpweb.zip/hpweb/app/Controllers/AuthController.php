<?php
class AuthController extends Controller {
    private UserModel $userModel;

    public function __construct() {
        $this->userModel = new UserModel();
    }

    public function loginForm(): void {
        if (!empty($_SESSION['user_id'])) $this->redirect(APP_URL . '/');
        $this->view('auth.login', [
            'title' => 'Đăng nhập - ' . APP_NAME,
            'flash' => $this->getFlash(),
        ]);
    }

    public function login(): void {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            $this->redirect(APP_URL . '/dang-nhap');
        }

        $email    = trim($this->post('email'));
        $password = $this->post('password');

        $user = $this->userModel->getByEmail($email);

        if (!$user || !$this->userModel->verifyPassword($password, $user['password'])) {
            $this->setFlash('error', 'Email hoặc mật khẩu không đúng');
            $this->redirect(APP_URL . '/dang-nhap');
        }

        if ($user['status'] != 1) {
            $this->setFlash('error', 'Tài khoản đã bị khóa');
            $this->redirect(APP_URL . '/dang-nhap');
        }

        $_SESSION['user_id']   = $user['id'];
        $_SESSION['user_name'] = $user['name'];
        $_SESSION['user_role'] = $user['role'];

        if ($user['role'] === 'admin') {
            $this->redirect(APP_URL . '/admin');
        } else {
            $redirect = $_SESSION['redirect_after_login'] ?? APP_URL . '/';
            unset($_SESSION['redirect_after_login']);
            $this->redirect($redirect);
        }
    }

    public function registerForm(): void {
        if (!empty($_SESSION['user_id'])) $this->redirect(APP_URL . '/');
        $this->view('auth.register', [
            'title' => 'Đăng ký - ' . APP_NAME,
            'flash' => $this->getFlash(),
        ]);
    }

    public function register(): void {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            $this->redirect(APP_URL . '/dang-ky');
        }

        $name     = trim($this->post('name'));
        $email    = trim($this->post('email'));
        $phone    = trim($this->post('phone'));
        $password = $this->post('password');
        $confirm  = $this->post('password_confirm');

        $errors = [];
        if (!$name)    $errors[] = 'Vui lòng nhập họ tên';
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) $errors[] = 'Email không hợp lệ';
        if (strlen($password) < 6) $errors[] = 'Mật khẩu tối thiểu 6 ký tự';
        if ($password !== $confirm) $errors[] = 'Mật khẩu xác nhận không khớp';
        if ($this->userModel->getByEmail($email)) $errors[] = 'Email đã được đăng ký';

        if ($errors) {
            $this->setFlash('error', implode('<br>', $errors));
            $this->redirect(APP_URL . '/dang-ky');
        }

        $id = $this->userModel->register([
            'name'  => $this->sanitize($name),
            'email' => $email,
            'phone' => $this->sanitize($phone),
            'password' => $password,
        ]);

        $_SESSION['user_id']   = $id;
        $_SESSION['user_name'] = $name;
        $_SESSION['user_role'] = 'customer';

        $this->setFlash('success', 'Đăng ký thành công! Chào mừng bạn đến với Vi Tính Net.');
        $this->redirect(APP_URL . '/');
    }

    public function logout(): void {
        unset($_SESSION['user_id'], $_SESSION['user_name'], $_SESSION['user_role']);
        $this->redirect(APP_URL . '/');
    }

    public function profile(): void {
        $this->requireAuth();
        $user  = $this->userModel->findById($_SESSION['user_id']);
        $orderModel = new OrderModel();
        $orders = $orderModel->getByUser($_SESSION['user_id']);

        $this->view('auth.profile', [
            'title'  => 'Tài khoản - ' . APP_NAME,
            'user'   => $user,
            'orders' => $orders,
            'flash'  => $this->getFlash(),
        ]);
    }

    public function updateProfile(): void {
        $this->requireAuth();
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            $this->redirect(APP_URL . '/tai-khoan');
        }

        $this->userModel->updateProfile($_SESSION['user_id'], [
            'name'    => $this->sanitize($this->post('name')),
            'phone'   => $this->sanitize($this->post('phone')),
            'address' => $this->sanitize($this->post('address')),
        ]);

        $_SESSION['user_name'] = $this->post('name');
        $this->setFlash('success', 'Cập nhật thông tin thành công');
        $this->redirect(APP_URL . '/tai-khoan');
    }
}

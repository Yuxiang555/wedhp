<?php
class UserModel extends Model {
    protected string $table = 'users';

    public function getByEmail(string $email): ?array {
        return $this->findOne('email = ?', [$email]);
    }

    public function register(array $data): string {
        $data['password'] = password_hash($data['password'], PASSWORD_BCRYPT);
        $data['role']     = 'customer';
        $data['status']   = 1;
        return $this->create($data);
    }

    public function verifyPassword(string $password, string $hash): bool {
        return password_verify($password, $hash);
    }

    public function updateProfile(int $id, array $data): int {
        unset($data['password'], $data['role']); // Không cho tự đổi role
        return $this->update($id, $data);
    }

    public function changePassword(int $id, string $newPassword): int {
        return $this->update($id, ['password' => password_hash($newPassword, PASSWORD_BCRYPT)]);
    }
}

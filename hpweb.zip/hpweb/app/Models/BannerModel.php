<?php
class BannerModel extends Model {
    protected string $table = 'banners';

    public function getActive(): array {
        return $this->findAll('status = 1', [], 'sort_order ASC');
    }
}

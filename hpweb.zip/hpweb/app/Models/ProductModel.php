<?php
class ProductModel extends Model {
    protected string $table = 'products';

    public function getWithCategory(int $id): ?array {
        return $this->db->queryOne("
            SELECT p.*, c.name AS category_name, c.slug AS category_slug,
                   b.name AS brand_name
            FROM products p
            LEFT JOIN categories c ON p.category_id = c.id
            LEFT JOIN brands b ON p.brand_id = b.id
            WHERE p.id = ? AND p.status = 1
        ", [$id]);
    }

    public function getBySlug(string $slug): ?array {
        return $this->db->queryOne("
            SELECT p.*, c.name AS category_name, c.slug AS category_slug,
                   b.name AS brand_name
            FROM products p
            LEFT JOIN categories c ON p.category_id = c.id
            LEFT JOIN brands b ON p.brand_id = b.id
            WHERE p.slug = ? AND p.status = 1
        ", [$slug]);
    }

    public function getByCategory(int $categoryId, int $limit = 12, int $offset = 0): array {
        return $this->db->query("
            SELECT p.*, c.name AS category_name, b.name AS brand_name
            FROM products p
            LEFT JOIN categories c ON p.category_id = c.id
            LEFT JOIN brands b ON p.brand_id = b.id
            WHERE p.category_id = ? AND p.status = 1
            ORDER BY p.created_at DESC
            LIMIT ? OFFSET ?
        ", [$categoryId, $limit, $offset]);
    }

    public function countByCategory(int $categoryId): int {
        $row = $this->db->queryOne(
            "SELECT COUNT(*) AS cnt FROM products WHERE category_id = ? AND status = 1",
            [$categoryId]
        );
        return (int)($row['cnt'] ?? 0);
    }

    public function getFeatured(int $limit = 8): array {
        return $this->db->query("
            SELECT p.*, b.name AS brand_name
            FROM products p
            LEFT JOIN brands b ON p.brand_id = b.id
            WHERE p.is_featured = 1 AND p.status = 1
            ORDER BY p.created_at DESC
            LIMIT ?
        ", [$limit]);
    }

    public function getNew(int $limit = 8): array {
        return $this->db->query("
            SELECT p.*, b.name AS brand_name
            FROM products p
            LEFT JOIN brands b ON p.brand_id = b.id
            WHERE p.is_new = 1 AND p.status = 1
            ORDER BY p.created_at DESC
            LIMIT ?
        ", [$limit]);
    }

    public function search(string $keyword, int $limit = 12, int $offset = 0): array {
        $kw = '%' . $keyword . '%';
        return $this->db->query("
            SELECT p.*, c.name AS category_name, b.name AS brand_name
            FROM products p
            LEFT JOIN categories c ON p.category_id = c.id
            LEFT JOIN brands b ON p.brand_id = b.id
            WHERE (p.name LIKE ? OR p.description LIKE ? OR p.sku LIKE ?) AND p.status = 1
            ORDER BY p.is_featured DESC, p.created_at DESC
            LIMIT ? OFFSET ?
        ", [$kw, $kw, $kw, $limit, $offset]);
    }

    public function countSearch(string $keyword): int {
        $kw = '%' . $keyword . '%';
        $row = $this->db->queryOne("
            SELECT COUNT(*) AS cnt FROM products
            WHERE (name LIKE ? OR description LIKE ? OR sku LIKE ?) AND status = 1
        ", [$kw, $kw, $kw]);
        return (int)($row['cnt'] ?? 0);
    }

    public function getRelated(int $categoryId, int $excludeId, int $limit = 4): array {
        return $this->db->query("
            SELECT p.*, b.name AS brand_name
            FROM products p
            LEFT JOIN brands b ON p.brand_id = b.id
            WHERE p.category_id = ? AND p.id != ? AND p.status = 1
            ORDER BY RAND()
            LIMIT ?
        ", [$categoryId, $excludeId, $limit]);
    }

    public function incrementView(int $id): void {
        $this->db->execute("UPDATE products SET view_count = view_count + 1 WHERE id = ?", [$id]);
    }

    public function getAllAdmin(string $search = '', int $limit = 20, int $offset = 0): array {
        $where  = '';
        $params = [];
        if ($search) {
            $where    = "WHERE p.name LIKE ? OR p.sku LIKE ?";
            $params[] = '%' . $search . '%';
            $params[] = '%' . $search . '%';
        }
        $params = array_merge($params, [$limit, $offset]);
        return $this->db->query("
            SELECT p.*, c.name AS category_name, b.name AS brand_name
            FROM products p
            LEFT JOIN categories c ON p.category_id = c.id
            LEFT JOIN brands b ON p.brand_id = b.id
            $where
            ORDER BY p.created_at DESC
            LIMIT ? OFFSET ?
        ", $params);
    }
}

<?php
class ContactModel extends Model {
    protected string $table = 'contacts';

    public function getUnread(): int {
        $row = $this->db->queryOne("SELECT COUNT(*) AS cnt FROM contacts WHERE is_read = 0");
        return (int)($row['cnt'] ?? 0);
    }
}

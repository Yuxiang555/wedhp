<?php
class OrderModel extends Model {
    protected string $table = 'orders';

    public function createOrder(array $order, array $items): string {
        $this->db->beginTransaction();
        try {
            $orderId = $this->create($order);
            foreach ($items as $item) {
                $item['order_id'] = $orderId;
                $cols   = implode(', ', array_map(fn($c) => "`$c`", array_keys($item)));
                $places = implode(', ', array_fill(0, count($item), '?'));
                $this->db->insert("INSERT INTO order_items ($cols) VALUES ($places)", array_values($item));
                // Trừ tồn kho
                $this->db->execute(
                    "UPDATE products SET stock = stock - ? WHERE id = ? AND stock >= ?",
                    [$item['quantity'], $item['product_id'], $item['quantity']]
                );
            }
            $this->db->commit();
            return $orderId;
        } catch (Exception $e) {
            $this->db->rollBack();
            throw $e;
        }
    }

    public function getWithItems(int $orderId): ?array {
        $order = $this->findById($orderId);
        if (!$order) return null;
        $order['items'] = $this->db->query("
            SELECT oi.*, p.slug AS product_slug
            FROM order_items oi
            LEFT JOIN products p ON oi.product_id = p.id
            WHERE oi.order_id = ?
        ", [$orderId]);
        return $order;
    }

    public function getByCode(string $code): ?array {
        $order = $this->findOne('order_code = ?', [$code]);
        if (!$order) return null;
        $order['items'] = $this->db->query("
            SELECT * FROM order_items WHERE order_id = ?
        ", [$order['id']]);
        return $order;
    }

    public function getByUser(int $userId): array {
        return $this->db->query("
            SELECT * FROM orders WHERE user_id = ? ORDER BY created_at DESC
        ", [$userId]);
    }

    public function getAllAdmin(string $status = '', int $limit = 20, int $offset = 0): array {
        $where  = '';
        $params = [];
        if ($status) {
            $where    = 'WHERE status = ?';
            $params[] = $status;
        }
        $params = array_merge($params, [$limit, $offset]);
        return $this->db->query("
            SELECT * FROM orders $where ORDER BY created_at DESC LIMIT ? OFFSET ?
        ", $params);
    }

    public function updateStatus(int $id, string $status): int {
        return $this->update($id, ['status' => $status]);
    }

    public function generateCode(): string {
        return 'VTN' . strtoupper(substr(md5(uniqid()), 0, 8));
    }

    public function getStats(): array {
        return $this->db->queryOne("
            SELECT
                COUNT(*) AS total_orders,
                SUM(CASE WHEN status = 'pending'   THEN 1 ELSE 0 END) AS pending,
                SUM(CASE WHEN status = 'delivered' THEN 1 ELSE 0 END) AS delivered,
                SUM(CASE WHEN status = 'cancelled' THEN 1 ELSE 0 END) AS cancelled,
                SUM(CASE WHEN status = 'delivered' THEN total_amount ELSE 0 END) AS revenue
            FROM orders
        ") ?? [];
    }
}

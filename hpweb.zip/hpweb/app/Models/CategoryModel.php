<?php
class CategoryModel extends Model {
    protected string $table = 'categories';

    public function getAll(): array {
        return $this->findAll('status = 1', [], 'sort_order ASC, name ASC');
    }

    public function getBySlug(string $slug): ?array {
        return $this->findOne('slug = ? AND status = 1', [$slug]);
    }

    public function getWithCount(): array {
        return $this->db->query("
            SELECT c.*, COUNT(p.id) AS product_count
            FROM categories c
            LEFT JOIN products p ON p.category_id = c.id AND p.status = 1
            WHERE c.status = 1
            GROUP BY c.id
            ORDER BY c.sort_order ASC
        ");
    }
}

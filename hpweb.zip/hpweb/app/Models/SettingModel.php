<?php
class SettingModel extends Model {
    protected string $table = 'settings';
    private static array $cache = [];

    public function get(string $key, string $default = ''): string {
        if (isset(self::$cache[$key])) return self::$cache[$key];
        $row = $this->findOne('key_name = ?', [$key]);
        $val = $row ? $row['value'] : $default;
        self::$cache[$key] = $val;
        return $val;
    }

    public function getAll(): array {
        $rows = $this->findAll();
        $result = [];
        foreach ($rows as $row) {
            $result[$row['key_name']] = $row['value'];
        }
        return $result;
    }

    public function set(string $key, string $value): void {
        $exists = $this->findOne('key_name = ?', [$key]);
        if ($exists) {
            $this->db->execute("UPDATE settings SET value = ? WHERE key_name = ?", [$value, $key]);
        } else {
            $this->create(['key_name' => $key, 'value' => $value]);
        }
        self::$cache[$key] = $value;
    }
}

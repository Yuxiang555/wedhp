<?php if (!empty($flash)): ?>
<div class="alert alert-<?= $flash['type'] ?>"><?= $flash['message'] ?></div>
<?php endif; ?>

<div class="admin-card">
    <form method="POST" action="<?= APP_URL ?>/admin/cai-dat/luu" class="admin-form">
        <div class="form-grid-2">
            <div class="form-section">
                <h4><i class="fas fa-store"></i> Thông tin cửa hàng</h4>
                <div class="form-group">
                    <label>Tên website</label>
                    <input type="text" name="site_name" value="<?= htmlspecialchars($settings['site_name'] ?? '') ?>">
                </div>
                <div class="form-group">
                    <label>Địa chỉ</label>
                    <textarea name="site_address" rows="2"><?= htmlspecialchars($settings['site_address'] ?? '') ?></textarea>
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label>Điện thoại</label>
                        <input type="text" name="site_phone" value="<?= htmlspecialchars($settings['site_phone'] ?? '') ?>">
                    </div>
                    <div class="form-group">
                        <label>Zalo</label>
                        <input type="text" name="site_zalo" value="<?= htmlspecialchars($settings['site_zalo'] ?? '') ?>">
                    </div>
                </div>
                <div class="form-group">
                    <label>Email</label>
                    <input type="email" name="site_email" value="<?= htmlspecialchars($settings['site_email'] ?? '') ?>">
                </div>
                <div class="form-group">
                    <label>Giờ làm việc</label>
                    <input type="text" name="site_hours" value="<?= htmlspecialchars($settings['site_hours'] ?? '') ?>">
                </div>
                <div class="form-group">
                    <label>Facebook</label>
                    <input type="url" name="site_facebook" value="<?= htmlspecialchars($settings['site_facebook'] ?? '') ?>">
                </div>
            </div>
            <div class="form-section">
                <h4><i class="fas fa-info-circle"></i> Hướng dẫn</h4>
                <div class="help-box">
                    <p><i class="fas fa-lightbulb"></i> Thông tin này hiển thị ở header, footer và trang liên hệ.</p>
                    <p><i class="fas fa-lightbulb"></i> Số điện thoại Zalo dùng để tạo nút chat Zalo.</p>
                </div>
            </div>
        </div>
        <div class="form-actions">
            <button type="submit" class="btn btn-primary"><i class="fas fa-save"></i> Lưu cài đặt</button>
        </div>
    </form>
</div>

<?php if (!empty($flash)): ?>
<div class="alert alert-<?= $flash['type'] ?>"><?= $flash['message'] ?></div>
<?php endif; ?>

<div class="admin-card">
    <form method="POST" action="<?= APP_URL ?>/admin/san-pham/cap-nhat/<?= $product['id'] ?>"
          enctype="multipart/form-data" class="admin-form">
        <div class="form-grid-2">
            <div class="form-section">
                <h4>Thông tin cơ bản</h4>
                <div class="form-group">
                    <label>Tên sản phẩm <span class="required">*</span></label>
                    <input type="text" name="name" required value="<?= htmlspecialchars($product['name']) ?>">
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label>Danh mục <span class="required">*</span></label>
                        <select name="category_id" required>
                            <?php foreach ($categories as $cat): ?>
                            <option value="<?= $cat['id'] ?>" <?= $cat['id'] == $product['category_id'] ? 'selected' : '' ?>>
                                <?= htmlspecialchars($cat['name']) ?>
                            </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Mã SKU</label>
                        <input type="text" name="sku" value="<?= htmlspecialchars($product['sku'] ?? '') ?>">
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label>Giá gốc (đ) <span class="required">*</span></label>
                        <input type="number" name="price" required min="0" value="<?= $product['price'] ?>">
                    </div>
                    <div class="form-group">
                        <label>Giá khuyến mãi (đ)</label>
                        <input type="number" name="sale_price" min="0" value="<?= $product['sale_price'] ?? '' ?>">
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label>Tồn kho</label>
                        <input type="number" name="stock" value="<?= $product['stock'] ?>" min="0">
                    </div>
                    <div class="form-group">
                        <label>Trạng thái</label>
                        <select name="status">
                            <option value="1" <?= $product['status'] ? 'selected' : '' ?>>Hiển thị</option>
                            <option value="0" <?= !$product['status'] ? 'selected' : '' ?>>Ẩn</option>
                        </select>
                    </div>
                </div>
                <div class="form-row">
                    <label class="checkbox-label">
                        <input type="checkbox" name="is_featured" value="1" <?= $product['is_featured'] ? 'checked' : '' ?>>
                        <span>Sản phẩm nổi bật</span>
                    </label>
                    <label class="checkbox-label">
                        <input type="checkbox" name="is_new" value="1" <?= $product['is_new'] ? 'checked' : '' ?>>
                        <span>Hàng mới về</span>
                    </label>
                </div>
            </div>

            <div class="form-section">
                <h4>Hình ảnh & Mô tả</h4>
                <div class="form-group">
                    <label>Ảnh sản phẩm</label>
                    <input type="file" name="image" accept="image/*" id="imageInput">
                    <div class="image-preview" id="imagePreview">
                        <?php if (!empty($product['image'])): ?>
                        <img src="<?= APP_URL ?>/public/images/products/<?= htmlspecialchars($product['image']) ?>"
                             style="max-height:200px;">
                        <?php else: ?>
                        <i class="fas fa-image"></i> Chọn ảnh để xem trước
                        <?php endif; ?>
                    </div>
                </div>
                <div class="form-group">
                    <label>Mô tả sản phẩm</label>
                    <textarea name="description" rows="4"><?= htmlspecialchars($product['description'] ?? '') ?></textarea>
                </div>
                <div class="form-group">
                    <label>Thông số kỹ thuật</label>
                    <textarea name="specs" rows="4"><?= htmlspecialchars($product['specs'] ?? '') ?></textarea>
                </div>
            </div>
        </div>

        <div class="form-actions">
            <button type="submit" class="btn btn-primary"><i class="fas fa-save"></i> Cập nhật</button>
            <a href="<?= APP_URL ?>/admin/san-pham" class="btn btn-outline">Hủy</a>
        </div>
    </form>
</div>
<script>
document.getElementById('imageInput').addEventListener('change', function() {
    const preview = document.getElementById('imagePreview');
    if (this.files && this.files[0]) {
        const reader = new FileReader();
        reader.onload = e => { preview.innerHTML = `<img src="${e.target.result}" style="max-height:200px">`; };
        reader.readAsDataURL(this.files[0]);
    }
});
</script>

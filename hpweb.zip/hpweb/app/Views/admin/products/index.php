<?php if (!empty($flash)): ?>
<div class="alert alert-<?= $flash['type'] ?>"><?= $flash['message'] ?></div>
<?php endif; ?>

<div class="admin-card">
    <div class="admin-card-header">
        <div class="card-header-left">
            <form method="GET" class="admin-search">
                <input type="text" name="search" placeholder="Tìm sản phẩm..." value="<?= htmlspecialchars($search) ?>">
                <button type="submit" class="btn btn-secondary"><i class="fas fa-search"></i></button>
            </form>
        </div>
        <a href="<?= APP_URL ?>/admin/san-pham/them" class="btn btn-primary">
            <i class="fas fa-plus"></i> Thêm sản phẩm
        </a>
    </div>

    <div class="table-wrap">
        <table class="admin-table">
            <thead>
                <tr>
                    <th width="60">Ảnh</th>
                    <th>Tên sản phẩm</th>
                    <th>Danh mục</th>
                    <th>Giá</th>
                    <th>Kho</th>
                    <th>Nổi bật</th>
                    <th>Trạng thái</th>
                    <th width="120">Thao tác</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($products as $p): ?>
                <tr>
                    <td>
                        <?php if (!empty($p['image'])): ?>
                            <img src="<?= APP_URL ?>/public/images/products/<?= htmlspecialchars($p['image']) ?>"
                                 width="50" height="50" style="object-fit:cover;border-radius:4px;">
                        <?php else: ?>
                            <div class="no-img-sm"><i class="fas fa-image"></i></div>
                        <?php endif; ?>
                    </td>
                    <td>
                        <strong><?= htmlspecialchars($p['name']) ?></strong>
                        <?php if (!empty($p['sku'])): ?>
                        <br><small class="text-muted">SKU: <?= htmlspecialchars($p['sku']) ?></small>
                        <?php endif; ?>
                    </td>
                    <td><?= htmlspecialchars($p['category_name'] ?? '-') ?></td>
                    <td>
                        <strong><?= number_format($p['sale_price'] ?: $p['price'], 0, ',', '.') ?>đ</strong>
                        <?php if (!empty($p['sale_price']) && $p['sale_price'] < $p['price']): ?>
                        <br><small class="text-muted line-through"><?= number_format($p['price'], 0, ',', '.') ?>đ</small>
                        <?php endif; ?>
                    </td>
                    <td>
                        <span class="<?= $p['stock'] <= 0 ? 'text-danger' : ($p['stock'] <= 5 ? 'text-warning' : 'text-success') ?>">
                            <?= $p['stock'] ?>
                        </span>
                    </td>
                    <td><?= $p['is_featured'] ? '<i class="fas fa-star text-warning"></i>' : '-' ?></td>
                    <td>
                        <span class="badge <?= $p['status'] ? 'badge-success' : 'badge-secondary' ?>">
                            <?= $p['status'] ? 'Hiển thị' : 'Ẩn' ?>
                        </span>
                    </td>
                    <td>
                        <a href="<?= APP_URL ?>/admin/san-pham/sua/<?= $p['id'] ?>" class="btn-icon" title="Sửa">
                            <i class="fas fa-edit"></i>
                        </a>
                        <a href="<?= APP_URL ?>/chi-tiet/<?= $p['slug'] ?>" target="_blank" class="btn-icon" title="Xem">
                            <i class="fas fa-eye"></i>
                        </a>
                        <a href="<?= APP_URL ?>/admin/san-pham/xoa/<?= $p['id'] ?>" class="btn-icon text-danger"
                           title="Xóa" onclick="return confirm('Xóa sản phẩm này?')">
                            <i class="fas fa-trash"></i>
                        </a>
                    </td>
                </tr>
                <?php endforeach; ?>
                <?php if (empty($products)): ?>
                <tr><td colspan="8" class="text-center text-muted">Không có sản phẩm nào</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <?php if ($totalPages > 1): ?>
    <div class="pagination">
        <?php for ($i = 1; $i <= $totalPages; $i++): ?>
        <a href="?page=<?= $i ?>&search=<?= urlencode($search) ?>"
           class="page-btn <?= $i === $page ? 'active' : '' ?>"><?= $i ?></a>
        <?php endfor; ?>
    </div>
    <?php endif; ?>
</div>

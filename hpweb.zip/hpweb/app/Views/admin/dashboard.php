<!-- STATS CARDS -->
<div class="stats-grid">
    <div class="stat-card stat-primary">
        <div class="stat-icon"><i class="fas fa-shopping-bag"></i></div>
        <div class="stat-info">
            <span class="stat-value"><?= number_format($stats['total_orders'] ?? 0) ?></span>
            <span class="stat-label">Tổng đơn hàng</span>
        </div>
    </div>
    <div class="stat-card stat-success">
        <div class="stat-icon"><i class="fas fa-coins"></i></div>
        <div class="stat-info">
            <span class="stat-value"><?= number_format($stats['revenue'] ?? 0, 0, ',', '.') ?>đ</span>
            <span class="stat-label">Doanh thu</span>
        </div>
    </div>
    <div class="stat-card stat-warning">
        <div class="stat-icon"><i class="fas fa-box"></i></div>
        <div class="stat-info">
            <span class="stat-value"><?= number_format($totalProducts) ?></span>
            <span class="stat-label">Sản phẩm</span>
        </div>
    </div>
    <div class="stat-card stat-info">
        <div class="stat-icon"><i class="fas fa-clock"></i></div>
        <div class="stat-info">
            <span class="stat-value"><?= number_format($stats['pending'] ?? 0) ?></span>
            <span class="stat-label">Chờ xử lý</span>
        </div>
    </div>
    <div class="stat-card stat-danger">
        <div class="stat-icon"><i class="fas fa-envelope"></i></div>
        <div class="stat-info">
            <span class="stat-value"><?= $unreadContacts ?></span>
            <span class="stat-label">Tin nhắn mới</span>
        </div>
    </div>
    <div class="stat-card stat-secondary">
        <div class="stat-icon"><i class="fas fa-tags"></i></div>
        <div class="stat-info">
            <span class="stat-value"><?= $totalCategories ?></span>
            <span class="stat-label">Danh mục</span>
        </div>
    </div>
</div>

<!-- QUICK LINKS -->
<div class="quick-links">
    <a href="<?= APP_URL ?>/admin/san-pham/them" class="quick-link">
        <i class="fas fa-plus-circle"></i> Thêm sản phẩm
    </a>
    <a href="<?= APP_URL ?>/admin/don-hang?status=pending" class="quick-link">
        <i class="fas fa-clock"></i> Đơn chờ xử lý
    </a>
    <a href="<?= APP_URL ?>/admin/lien-he" class="quick-link">
        <i class="fas fa-envelope"></i> Tin nhắn mới
    </a>
    <a href="<?= APP_URL ?>/admin/cai-dat" class="quick-link">
        <i class="fas fa-cog"></i> Cài đặt
    </a>
</div>

<!-- ĐƠN HÀNG GẦN ĐÂY -->
<div class="admin-card">
    <div class="admin-card-header">
        <h3>Đơn hàng gần đây</h3>
        <a href="<?= APP_URL ?>/admin/don-hang" class="btn-sm">Xem tất cả</a>
    </div>
    <div class="table-wrap">
        <table class="admin-table">
            <thead>
                <tr>
                    <th>Mã đơn</th>
                    <th>Khách hàng</th>
                    <th>Điện thoại</th>
                    <th>Tổng tiền</th>
                    <th>Trạng thái</th>
                    <th>Ngày đặt</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $statusMap = [
                    'pending'   => ['Chờ xác nhận', 'badge-warning'],
                    'confirmed' => ['Đã xác nhận',  'badge-info'],
                    'shipping'  => ['Đang giao',    'badge-primary'],
                    'delivered' => ['Đã giao',      'badge-success'],
                    'cancelled' => ['Đã hủy',       'badge-danger'],
                ];
                foreach ($recentOrders as $order):
                    $st = $statusMap[$order['status']] ?? ['Không rõ', 'badge-secondary'];
                ?>
                <tr>
                    <td><a href="<?= APP_URL ?>/admin/don-hang/<?= $order['id'] ?>">#<?= $order['order_code'] ?></a></td>
                    <td><?= htmlspecialchars($order['customer_name']) ?></td>
                    <td><?= htmlspecialchars($order['customer_phone']) ?></td>
                    <td><strong><?= number_format($order['total_amount'], 0, ',', '.') ?>đ</strong></td>
                    <td><span class="badge <?= $st[1] ?>"><?= $st[0] ?></span></td>
                    <td><?= date('d/m/Y H:i', strtotime($order['created_at'])) ?></td>
                </tr>
                <?php endforeach; ?>
                <?php if (empty($recentOrders)): ?>
                <tr><td colspan="6" class="text-center text-muted">Chưa có đơn hàng nào</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php if (!empty($flash)): ?>
<div class="alert alert-<?= $flash['type'] ?>"><?= $flash['message'] ?></div>
<?php endif; ?>

<div class="admin-card">
    <div class="admin-card-header">
        <div class="status-tabs">
            <a href="<?= APP_URL ?>/admin/don-hang" class="<?= !$status ? 'active' : '' ?>">Tất cả (<?= $totalItems ?>)</a>
            <?php foreach (['pending'=>'Chờ xử lý','confirmed'=>'Đã xác nhận','shipping'=>'Đang giao','delivered'=>'Đã giao','cancelled'=>'Đã hủy'] as $k=>$v): ?>
            <a href="?status=<?= $k ?>" class="<?= $status === $k ? 'active' : '' ?>"><?= $v ?></a>
            <?php endforeach; ?>
        </div>
    </div>

    <div class="table-wrap">
        <table class="admin-table">
            <thead>
                <tr>
                    <th>Mã đơn</th>
                    <th>Khách hàng</th>
                    <th>Điện thoại</th>
                    <th>Địa chỉ</th>
                    <th>Tổng tiền</th>
                    <th>Thanh toán</th>
                    <th>Trạng thái</th>
                    <th>Ngày đặt</th>
                    <th>Thao tác</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $statusMap = [
                    'pending'   => ['Chờ xác nhận', 'badge-warning'],
                    'confirmed' => ['Đã xác nhận',  'badge-info'],
                    'shipping'  => ['Đang giao',    'badge-primary'],
                    'delivered' => ['Đã giao',      'badge-success'],
                    'cancelled' => ['Đã hủy',       'badge-danger'],
                ];
                foreach ($orders as $order):
                    $st = $statusMap[$order['status']] ?? ['?', 'badge-secondary'];
                ?>
                <tr>
                    <td><strong>#<?= $order['order_code'] ?></strong></td>
                    <td><?= htmlspecialchars($order['customer_name']) ?></td>
                    <td><?= htmlspecialchars($order['customer_phone']) ?></td>
                    <td class="text-truncate" style="max-width:150px;"><?= htmlspecialchars($order['shipping_address']) ?></td>
                    <td><strong><?= number_format($order['total_amount'], 0, ',', '.') ?>đ</strong></td>
                    <td><?= $order['payment_method'] === 'cod' ? 'COD' : 'CK' ?></td>
                    <td><span class="badge <?= $st[1] ?>"><?= $st[0] ?></span></td>
                    <td><?= date('d/m/Y', strtotime($order['created_at'])) ?></td>
                    <td>
                        <a href="<?= APP_URL ?>/admin/don-hang/<?= $order['id'] ?>" class="btn-sm btn-primary">
                            <i class="fas fa-eye"></i> Chi tiết
                        </a>
                    </td>
                </tr>
                <?php endforeach; ?>
                <?php if (empty($orders)): ?>
                <tr><td colspan="9" class="text-center text-muted">Không có đơn hàng</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <?php if ($totalPages > 1): ?>
    <div class="pagination">
        <?php for ($i = 1; $i <= $totalPages; $i++): ?>
        <a href="?page=<?= $i ?>&status=<?= $status ?>" class="page-btn <?= $i === $page ? 'active' : '' ?>"><?= $i ?></a>
        <?php endfor; ?>
    </div>
    <?php endif; ?>
</div>

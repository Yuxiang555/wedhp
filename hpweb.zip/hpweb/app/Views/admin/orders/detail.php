<?php
$statusMap = [
    'pending'   => ['Chờ xác nhận', 'badge-warning'],
    'confirmed' => ['Đã xác nhận',  'badge-info'],
    'shipping'  => ['Đang giao',    'badge-primary'],
    'delivered' => ['Đã giao',      'badge-success'],
    'cancelled' => ['Đã hủy',       'badge-danger'],
];
$st = $statusMap[$order['status']] ?? ['?', 'badge-secondary'];
?>
<?php if (!empty($flash)): ?>
<div class="alert alert-<?= $flash['type'] ?>"><?= $flash['message'] ?></div>
<?php endif; ?>

<div class="form-grid-2">
    <div class="admin-card">
        <h4>Thông tin đơn hàng #<?= $order['order_code'] ?></h4>
        <table class="info-table">
            <tr><td>Khách hàng</td><td><?= htmlspecialchars($order['customer_name']) ?></td></tr>
            <tr><td>Điện thoại</td><td><a href="tel:<?= $order['customer_phone'] ?>"><?= $order['customer_phone'] ?></a></td></tr>
            <tr><td>Email</td><td><?= htmlspecialchars($order['customer_email'] ?? '-') ?></td></tr>
            <tr><td>Địa chỉ</td><td><?= htmlspecialchars($order['shipping_address']) ?></td></tr>
            <tr><td>Ghi chú</td><td><?= htmlspecialchars($order['note'] ?? '-') ?></td></tr>
            <tr><td>Thanh toán</td><td><?= $order['payment_method'] === 'cod' ? 'Tiền mặt (COD)' : 'Chuyển khoản' ?></td></tr>
            <tr><td>Ngày đặt</td><td><?= date('d/m/Y H:i', strtotime($order['created_at'])) ?></td></tr>
            <tr><td>Trạng thái</td><td><span class="badge <?= $st[1] ?>"><?= $st[0] ?></span></td></tr>
        </table>

        <form method="POST" action="<?= APP_URL ?>/admin/don-hang/cap-nhat/<?= $order['id'] ?>" style="margin-top:1rem;">
            <div class="form-row">
                <div class="form-group">
                    <select name="status">
                        <?php foreach ($statusMap as $k => [$label, $cls]): ?>
                        <option value="<?= $k ?>" <?= $order['status'] === $k ? 'selected' : '' ?>><?= $label ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <button type="submit" class="btn btn-primary">Cập nhật trạng thái</button>
            </div>
        </form>
    </div>

    <div class="admin-card">
        <h4>Sản phẩm đã đặt</h4>
        <?php foreach ($order['items'] as $item): ?>
        <div class="order-item-detail">
            <div>
                <strong><?= htmlspecialchars($item['product_name']) ?></strong><br>
                <small>Đơn giá: <?= number_format($item['price'], 0, ',', '.') ?>đ &times; <?= $item['quantity'] ?></small>
            </div>
            <strong><?= number_format($item['subtotal'], 0, ',', '.') ?>đ</strong>
        </div>
        <?php endforeach; ?>
        <div class="order-total-row">
            <strong>Tổng cộng:</strong>
            <strong class="price-big"><?= number_format($order['total_amount'], 0, ',', '.') ?>đ</strong>
        </div>
    </div>
</div>

<a href="<?= APP_URL ?>/admin/don-hang" class="btn btn-outline"><i class="fas fa-arrow-left"></i> Quay lại</a>

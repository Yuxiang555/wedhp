<div class="admin-card">
    <div class="table-wrap">
        <table class="admin-table">
            <thead>
                <tr>
                    <th>Họ tên</th>
                    <th>Điện thoại</th>
                    <th>Email</th>
                    <th>Chủ đề</th>
                    <th>Nội dung</th>
                    <th>Ngày gửi</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($contacts as $c): ?>
                <tr>
                    <td><strong><?= htmlspecialchars($c['name']) ?></strong></td>
                    <td><?= htmlspecialchars($c['phone'] ?? '-') ?></td>
                    <td><?= htmlspecialchars($c['email'] ?? '-') ?></td>
                    <td><?= htmlspecialchars($c['subject'] ?? '-') ?></td>
                    <td style="max-width:300px;"><?= htmlspecialchars($c['message']) ?></td>
                    <td><?= date('d/m/Y H:i', strtotime($c['created_at'])) ?></td>
                </tr>
                <?php endforeach; ?>
                <?php if (empty($contacts)): ?>
                <tr><td colspan="6" class="text-center text-muted">Chưa có tin nhắn nào</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

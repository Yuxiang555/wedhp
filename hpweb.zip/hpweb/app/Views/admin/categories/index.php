<?php if (!empty($flash)): ?>
<div class="alert alert-<?= $flash['type'] ?>"><?= $flash['message'] ?></div>
<?php endif; ?>

<div class="form-grid-2">
    <div class="admin-card">
        <h4>Thêm danh mục mới</h4>
        <form method="POST" action="<?= APP_URL ?>/admin/danh-muc/luu">
            <div class="form-group">
                <label>Tên danh mục <span class="required">*</span></label>
                <input type="text" name="name" required placeholder="VD: Laptop">
            </div>
            <div class="form-row">
                <div class="form-group">
                    <label>Icon FontAwesome</label>
                    <input type="text" name="icon" placeholder="fa-laptop">
                </div>
                <div class="form-group">
                    <label>Thứ tự</label>
                    <input type="number" name="sort_order" value="0" min="0">
                </div>
            </div>
            <button type="submit" class="btn btn-primary"><i class="fas fa-plus"></i> Thêm danh mục</button>
        </form>
    </div>

    <div class="admin-card">
        <h4>Danh sách danh mục</h4>
        <table class="admin-table">
            <thead>
                <tr>
                    <th>Icon</th>
                    <th>Tên danh mục</th>
                    <th>Slug</th>
                    <th>SP</th>
                    <th></th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($categories as $cat): ?>
                <tr>
                    <td><i class="fas <?= htmlspecialchars($cat['icon'] ?? 'fa-tag') ?>"></i></td>
                    <td><?= htmlspecialchars($cat['name']) ?></td>
                    <td><small><?= htmlspecialchars($cat['slug']) ?></small></td>
                    <td><?= $cat['product_count'] ?></td>
                    <td>
                        <a href="<?= APP_URL ?>/admin/danh-muc/xoa/<?= $cat['id'] ?>"
                           class="btn-icon text-danger"
                           onclick="return confirm('Xóa danh mục này? Sản phẩm sẽ không bị xóa.')">
                            <i class="fas fa-trash"></i>
                        </a>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

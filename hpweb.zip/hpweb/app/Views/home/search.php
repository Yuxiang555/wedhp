<div class="container">
    <nav class="breadcrumb">
        <a href="<?= APP_URL ?>/">Trang chủ</a>
        <i class="fas fa-chevron-right"></i>
        <span>Tìm kiếm</span>
    </nav>

    <div class="search-header">
        <h1>Kết quả tìm kiếm: "<?= htmlspecialchars($keyword) ?>"</h1>
        <span><?= $totalItems ?> sản phẩm được tìm thấy</span>
    </div>

    <form class="search-bar-inline" method="GET" action="<?= APP_URL ?>/tim-kiem">
        <input type="text" name="q" value="<?= htmlspecialchars($keyword) ?>" placeholder="Tìm kiếm sản phẩm...">
        <button type="submit" class="btn btn-primary"><i class="fas fa-search"></i> Tìm</button>
    </form>

    <?php if (!empty($products)): ?>
    <div class="product-grid">
        <?php foreach ($products as $product): ?>
        <?php include __DIR__ . '/../products/_card.php'; ?>
        <?php endforeach; ?>
    </div>

    <?php if ($totalPages > 1): ?>
    <div class="pagination">
        <?php if ($page > 1): ?>
            <a href="?q=<?= urlencode($keyword) ?>&page=<?= $page - 1 ?>" class="page-btn">
                <i class="fas fa-chevron-left"></i>
            </a>
        <?php endif; ?>
        <?php for ($i = max(1, $page - 2); $i <= min($totalPages, $page + 2); $i++): ?>
            <a href="?q=<?= urlencode($keyword) ?>&page=<?= $i ?>"
               class="page-btn <?= $i === $page ? 'active' : '' ?>"><?= $i ?></a>
        <?php endfor; ?>
        <?php if ($page < $totalPages): ?>
            <a href="?q=<?= urlencode($keyword) ?>&page=<?= $page + 1 ?>" class="page-btn">
                <i class="fas fa-chevron-right"></i>
            </a>
        <?php endif; ?>
    </div>
    <?php endif; ?>

    <?php elseif ($keyword !== ''): ?>
    <div class="empty-state">
        <i class="fas fa-search"></i>
        <h3>Không tìm thấy sản phẩm nào</h3>
        <p>Thử tìm với từ khóa khác hoặc liên hệ <a href="tel:0907111106">0907 1111 06</a> để được tư vấn</p>
        <a href="<?= APP_URL ?>/" class="btn btn-primary">Về trang chủ</a>
    </div>
    <?php endif; ?>
</div>

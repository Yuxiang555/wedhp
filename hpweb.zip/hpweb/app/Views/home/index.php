<?php
function formatPrice($price) {
    return number_format($price, 0, ',', '.') . 'đ';
}
?>

<!-- HERO / BANNER SLIDER -->
<section class="hero-slider">
    <?php if (!empty($banners)): ?>
        <div class="slider" id="heroSlider">
            <?php foreach ($banners as $i => $banner): ?>
            <div class="slide <?= $i === 0 ? 'active' : '' ?>">
                <a href="<?= htmlspecialchars($banner['link']) ?>">
                    <img src="<?= APP_URL ?>/public/images/banners/<?= htmlspecialchars($banner['image']) ?>"
                         alt="<?= htmlspecialchars($banner['title'] ?? '') ?>">
                </a>
            </div>
            <?php endforeach; ?>
            <button class="slide-prev"><i class="fas fa-chevron-left"></i></button>
            <button class="slide-next"><i class="fas fa-chevron-right"></i></button>
            <div class="slide-dots">
                <?php foreach ($banners as $i => $_): ?>
                    <span class="dot <?= $i === 0 ? 'active' : '' ?>" data-slide="<?= $i ?>"></span>
                <?php endforeach; ?>
            </div>
        </div>
    <?php else: ?>
    <div class="hero-fallback">
        <div class="container">
            <h2>Kho Vi Tính Giá Nét</h2>
            <p>Linh kiện chính hãng · Giá tốt nhất · Bảo hành tận tâm</p>
            <a href="<?= APP_URL ?>/san-pham/linh-kien-khac" class="btn btn-primary">Xem sản phẩm</a>
        </div>
    </div>
    <?php endif; ?>
</section>

<!-- PROMO BAR -->
<div class="promo-bar">
    <div class="container">
        <div class="promo-items">
            <div class="promo-item"><i class="fas fa-shield-alt"></i><span>Hàng chính hãng 100%</span></div>
            <div class="promo-item"><i class="fas fa-tags"></i><span>Giá cạnh tranh nhất</span></div>
            <div class="promo-item"><i class="fas fa-tools"></i><span>Bảo hành tận tâm</span></div>
            <div class="promo-item"><i class="fas fa-motorcycle"></i><span>Giao hàng nhanh HCM</span></div>
            <div class="promo-item"><i class="fas fa-phone-alt"></i><span>Hỗ trợ 09h - 18h</span></div>
        </div>
    </div>
</div>

<!-- DANH MỤC -->
<section class="section">
    <div class="container">
        <h2 class="section-title"><i class="fas fa-th-large"></i> Danh mục sản phẩm</h2>
        <div class="category-grid">
            <?php foreach ($categories as $cat): ?>
            <a href="<?= APP_URL ?>/san-pham/<?= $cat['slug'] ?>" class="category-card">
                <div class="category-icon">
                    <i class="fas <?= $cat['icon'] ?? 'fa-tag' ?>"></i>
                </div>
                <div class="category-info">
                    <span class="category-name"><?= htmlspecialchars($cat['name']) ?></span>
                    <span class="category-count"><?= $cat['product_count'] ?> sản phẩm</span>
                </div>
            </a>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<!-- SẢN PHẨM NỔI BẬT -->
<?php if (!empty($featuredProducts)): ?>
<section class="section bg-light">
    <div class="container">
        <div class="section-header">
            <h2 class="section-title"><i class="fas fa-fire"></i> Sản phẩm nổi bật</h2>
            <a href="<?= APP_URL ?>/san-pham/linh-kien-khac" class="see-all">Xem tất cả <i class="fas fa-chevron-right"></i></a>
        </div>
        <div class="product-grid">
            <?php foreach ($featuredProducts as $product): ?>
            <?php include __DIR__ . '/../products/_card.php'; ?>
            <?php endforeach; ?>
        </div>
    </div>
</section>
<?php endif; ?>

<!-- BANNER GIỮA -->
<div class="mid-banner">
    <div class="container">
        <div class="mid-banner-inner">
            <div class="mid-banner-content">
                <h3>🔥 Linh kiện chính hãng - Giá cực nét</h3>
                <p>Intel, AMD, ASUS, MSI, Kingston, WD... Hàng có sẵn, ship nhanh nội thành HCM</p>
                <a href="tel:0907111106" class="btn btn-primary"><i class="fas fa-phone-alt"></i> Gọi tư vấn ngay</a>
            </div>
            <div class="mid-banner-info">
                <div><i class="fas fa-map-marker-alt"></i> 19/6/24 Hoàng Xuân Nhị, P.Tân Phú, TP.HCM</div>
                <div><i class="fas fa-clock"></i> 09h - 18h (Chủ Nhật nghỉ)</div>
                <div><i class="fab fa-whatsapp"></i> Zalo tư vấn: 0907 1111 06</div>
            </div>
        </div>
    </div>
</div>

<!-- SẢN PHẨM MỚI -->
<?php if (!empty($newProducts)): ?>
<section class="section">
    <div class="container">
        <div class="section-header">
            <h2 class="section-title"><i class="fas fa-star"></i> Hàng mới về</h2>
            <a href="<?= APP_URL ?>/tim-kiem?q=" class="see-all">Xem tất cả <i class="fas fa-chevron-right"></i></a>
        </div>
        <div class="product-grid">
            <?php foreach ($newProducts as $product): ?>
            <?php include __DIR__ . '/../products/_card.php'; ?>
            <?php endforeach; ?>
        </div>
    </div>
</section>
<?php endif; ?>

<div class="container">
    <div class="auth-wrap">
        <div class="auth-card">
            <h2><i class="fas fa-sign-in-alt"></i> Đăng nhập</h2>

            <?php if (!empty($flash)): ?>
            <div class="alert alert-<?= $flash['type'] ?>"><?= $flash['message'] ?></div>
            <?php endif; ?>

            <form method="POST" action="<?= APP_URL ?>/dang-nhap/xu-ly" class="auth-form">
                <div class="form-group">
                    <label><i class="fas fa-envelope"></i> Email</label>
                    <input type="email" name="email" required placeholder="Nhập địa chỉ email" autofocus>
                </div>
                <div class="form-group">
                    <label><i class="fas fa-lock"></i> Mật khẩu</label>
                    <div class="password-wrap">
                        <input type="password" name="password" id="password" required placeholder="Nhập mật khẩu">
                        <button type="button" class="toggle-password" data-target="password">
                            <i class="fas fa-eye"></i>
                        </button>
                    </div>
                </div>
                <button type="submit" class="btn btn-primary btn-block btn-lg">
                    <i class="fas fa-sign-in-alt"></i> Đăng nhập
                </button>
            </form>

            <div class="auth-links">
                <p>Chưa có tài khoản? <a href="<?= APP_URL ?>/dang-ky">Đăng ký ngay</a></p>
            </div>
        </div>
    </div>
</div>

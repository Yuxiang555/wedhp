<div class="container">
    <div class="auth-wrap">
        <div class="auth-card">
            <h2><i class="fas fa-user-plus"></i> Đăng ký tài khoản</h2>

            <?php if (!empty($flash)): ?>
            <div class="alert alert-<?= $flash['type'] ?>"><?= $flash['message'] ?></div>
            <?php endif; ?>

            <form method="POST" action="<?= APP_URL ?>/dang-ky/xu-ly" class="auth-form">
                <div class="form-group">
                    <label>Họ và tên <span class="required">*</span></label>
                    <input type="text" name="name" required placeholder="Nguyễn Văn A">
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label>Email <span class="required">*</span></label>
                        <input type="email" name="email" required placeholder="email@example.com">
                    </div>
                    <div class="form-group">
                        <label>Số điện thoại</label>
                        <input type="tel" name="phone" placeholder="09xxxxxxxx">
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label>Mật khẩu <span class="required">*</span></label>
                        <div class="password-wrap">
                            <input type="password" name="password" id="pw1" required placeholder="Tối thiểu 6 ký tự">
                            <button type="button" class="toggle-password" data-target="pw1"><i class="fas fa-eye"></i></button>
                        </div>
                    </div>
                    <div class="form-group">
                        <label>Xác nhận mật khẩu <span class="required">*</span></label>
                        <div class="password-wrap">
                            <input type="password" name="password_confirm" id="pw2" required placeholder="Nhập lại mật khẩu">
                            <button type="button" class="toggle-password" data-target="pw2"><i class="fas fa-eye"></i></button>
                        </div>
                    </div>
                </div>
                <button type="submit" class="btn btn-primary btn-block btn-lg">
                    <i class="fas fa-user-plus"></i> Tạo tài khoản
                </button>
            </form>

            <div class="auth-links">
                <p>Đã có tài khoản? <a href="<?= APP_URL ?>/dang-nhap">Đăng nhập</a></p>
            </div>
        </div>
    </div>
</div>

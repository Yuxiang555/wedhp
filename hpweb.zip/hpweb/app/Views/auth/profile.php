<div class="container">
    <h1 class="page-title"><i class="fas fa-user-circle"></i> Tài khoản của tôi</h1>

    <?php if (!empty($flash)): ?>
    <div class="alert alert-<?= $flash['type'] ?>"><?= $flash['message'] ?></div>
    <?php endif; ?>

    <div class="profile-layout">
        <!-- THÔNG TIN TÀI KHOẢN -->
        <div class="profile-card">
            <h3>Thông tin cá nhân</h3>
            <form method="POST" action="<?= APP_URL ?>/tai-khoan/cap-nhat">
                <div class="form-group">
                    <label>Họ và tên</label>
                    <input type="text" name="name" value="<?= htmlspecialchars($user['name']) ?>" required>
                </div>
                <div class="form-group">
                    <label>Email</label>
                    <input type="email" value="<?= htmlspecialchars($user['email']) ?>" disabled class="disabled">
                </div>
                <div class="form-group">
                    <label>Số điện thoại</label>
                    <input type="tel" name="phone" value="<?= htmlspecialchars($user['phone'] ?? '') ?>">
                </div>
                <div class="form-group">
                    <label>Địa chỉ mặc định</label>
                    <textarea name="address" rows="2"><?= htmlspecialchars($user['address'] ?? '') ?></textarea>
                </div>
                <button type="submit" class="btn btn-primary"><i class="fas fa-save"></i> Lưu thay đổi</button>
            </form>
        </div>

        <!-- LỊCH SỬ ĐƠN HÀNG -->
        <div class="profile-orders">
            <h3>Lịch sử đơn hàng</h3>
            <?php if (!empty($orders)): ?>
            <div class="orders-table-wrap">
                <table class="orders-table">
                    <thead>
                        <tr>
                            <th>Mã đơn</th>
                            <th>Ngày đặt</th>
                            <th>Tổng tiền</th>
                            <th>Trạng thái</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $statusMap = [
                            'pending'   => ['Chờ xác nhận', 'badge-warning'],
                            'confirmed' => ['Đã xác nhận',  'badge-info'],
                            'shipping'  => ['Đang giao',    'badge-primary'],
                            'delivered' => ['Đã giao',      'badge-success'],
                            'cancelled' => ['Đã hủy',       'badge-danger'],
                        ];
                        foreach ($orders as $order):
                            $st = $statusMap[$order['status']] ?? ['Không rõ', 'badge-secondary'];
                        ?>
                        <tr>
                            <td><strong>#<?= htmlspecialchars($order['order_code']) ?></strong></td>
                            <td><?= date('d/m/Y', strtotime($order['created_at'])) ?></td>
                            <td><strong><?= number_format($order['total_amount'], 0, ',', '.') ?>đ</strong></td>
                            <td><span class="badge <?= $st[1] ?>"><?= $st[0] ?></span></td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            <?php else: ?>
            <div class="empty-state">
                <i class="fas fa-shopping-bag"></i>
                <p>Bạn chưa có đơn hàng nào</p>
                <a href="<?= APP_URL ?>/" class="btn btn-primary">Mua sắm ngay</a>
            </div>
            <?php endif; ?>
        </div>
    </div>
</div>

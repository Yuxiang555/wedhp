<div class="container">
    <nav class="breadcrumb">
        <a href="<?= APP_URL ?>/">Trang chủ</a>
        <i class="fas fa-chevron-right"></i>
        <a href="<?= APP_URL ?>/gio-hang">Giỏ hàng</a>
        <i class="fas fa-chevron-right"></i>
        <span>Đặt hàng</span>
    </nav>

    <h1 class="page-title"><i class="fas fa-file-invoice"></i> Thông tin đặt hàng</h1>

    <?php if (!empty($flash)): ?>
    <div class="alert alert-<?= $flash['type'] ?>"><?= $flash['message'] ?></div>
    <?php endif; ?>

    <form method="POST" action="<?= APP_URL ?>/dat-hang/xu-ly" class="checkout-form">
        <div class="checkout-layout">
            <!-- THÔNG TIN KHÁCH HÀNG -->
            <div class="checkout-info">
                <div class="checkout-block">
                    <h3><i class="fas fa-user"></i> Thông tin nhận hàng</h3>
                    <div class="form-row">
                        <div class="form-group">
                            <label>Họ và tên <span class="required">*</span></label>
                            <input type="text" name="customer_name" required placeholder="Nguyễn Văn A"
                                   value="<?= htmlspecialchars($user['name'] ?? '') ?>">
                        </div>
                        <div class="form-group">
                            <label>Số điện thoại <span class="required">*</span></label>
                            <input type="tel" name="customer_phone" required placeholder="09xxxxxxxx"
                                   value="<?= htmlspecialchars($user['phone'] ?? '') ?>">
                        </div>
                    </div>
                    <div class="form-group">
                        <label>Email</label>
                        <input type="email" name="customer_email" placeholder="email@example.com"
                               value="<?= htmlspecialchars($user['email'] ?? '') ?>">
                    </div>
                    <div class="form-group">
                        <label>Địa chỉ nhận hàng <span class="required">*</span></label>
                        <textarea name="shipping_address" required rows="3"
                                  placeholder="Số nhà, tên đường, phường/xã, quận/huyện, tỉnh/thành"><?= htmlspecialchars($user['address'] ?? '') ?></textarea>
                    </div>
                    <div class="form-group">
                        <label>Ghi chú đơn hàng</label>
                        <textarea name="note" rows="2" placeholder="Ghi chú thêm (nếu có)..."></textarea>
                    </div>
                </div>

                <div class="checkout-block">
                    <h3><i class="fas fa-credit-card"></i> Phương thức thanh toán</h3>
                    <div class="payment-options">
                        <label class="payment-option">
                            <input type="radio" name="payment_method" value="cod" checked>
                            <div class="payment-label">
                                <i class="fas fa-money-bill-wave"></i>
                                <div>
                                    <strong>Thanh toán khi nhận hàng (COD)</strong>
                                    <p>Thanh toán tiền mặt khi nhận được hàng</p>
                                </div>
                            </div>
                        </label>
                        <label class="payment-option">
                            <input type="radio" name="payment_method" value="bank_transfer">
                            <div class="payment-label">
                                <i class="fas fa-university"></i>
                                <div>
                                    <strong>Chuyển khoản ngân hàng</strong>
                                    <p><?= htmlspecialchars($settings['bank_name'] ?? 'Vietcombank') ?> -
                                       STK: <?= htmlspecialchars($settings['bank_account'] ?? '') ?> -
                                       <?= htmlspecialchars($settings['bank_owner'] ?? '') ?></p>
                                </div>
                            </div>
                        </label>
                    </div>
                </div>
            </div>

            <!-- ORDER SUMMARY -->
            <div class="checkout-summary">
                <div class="checkout-block">
                    <h3><i class="fas fa-shopping-bag"></i> Đơn hàng (<?= count($items) ?> sản phẩm)</h3>
                    <div class="order-items">
                        <?php foreach ($items as $item): ?>
                        <div class="order-item-row">
                            <div class="order-item-img">
                                <?php if (!empty($item['product']['image'])): ?>
                                    <img src="<?= APP_URL ?>/public/images/products/<?= htmlspecialchars($item['product']['image']) ?>"
                                         alt="<?= htmlspecialchars($item['product']['name']) ?>">
                                <?php else: ?>
                                    <div class="no-img"><i class="fas fa-image"></i></div>
                                <?php endif; ?>
                                <span class="item-qty"><?= $item['quantity'] ?></span>
                            </div>
                            <div class="order-item-info">
                                <span><?= htmlspecialchars($item['product']['name']) ?></span>
                                <strong><?= number_format($item['subtotal'], 0, ',', '.') ?>đ</strong>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                    <div class="summary-row">
                        <span>Tạm tính:</span>
                        <span><?= number_format($total, 0, ',', '.') ?>đ</span>
                    </div>
                    <div class="summary-row">
                        <span>Vận chuyển:</span>
                        <span class="text-success">Miễn phí</span>
                    </div>
                    <div class="summary-total">
                        <span>Tổng thanh toán:</span>
                        <strong><?= number_format($total, 0, ',', '.') ?>đ</strong>
                    </div>
                    <button type="submit" class="btn btn-primary btn-block btn-lg">
                        <i class="fas fa-check-circle"></i> Xác nhận đặt hàng
                    </button>
                    <a href="<?= APP_URL ?>/gio-hang" class="btn btn-outline btn-block">
                        <i class="fas fa-arrow-left"></i> Quay lại giỏ hàng
                    </a>
                </div>
            </div>
        </div>
    </form>
</div>

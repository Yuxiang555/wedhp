<div class="container">
    <div class="success-page">
        <div class="success-icon"><i class="fas fa-check-circle"></i></div>
        <h1>Đặt hàng thành công!</h1>
        <p class="success-msg">Cảm ơn bạn đã mua hàng tại Vi Tính Net. Chúng tôi sẽ liên hệ xác nhận trong thời gian sớm nhất.</p>

        <?php if ($order): ?>
        <div class="order-confirmation">
            <h3>Thông tin đơn hàng</h3>
            <div class="order-info-grid">
                <div><span>Mã đơn hàng:</span><strong>#<?= htmlspecialchars($order['order_code']) ?></strong></div>
                <div><span>Khách hàng:</span><strong><?= htmlspecialchars($order['customer_name']) ?></strong></div>
                <div><span>Điện thoại:</span><strong><?= htmlspecialchars($order['customer_phone']) ?></strong></div>
                <div><span>Địa chỉ giao:</span><strong><?= htmlspecialchars($order['shipping_address']) ?></strong></div>
                <div><span>Thanh toán:</span><strong><?= $order['payment_method'] === 'cod' ? 'Tiền mặt khi nhận hàng' : 'Chuyển khoản' ?></strong></div>
                <div><span>Tổng tiền:</span><strong class="price-big"><?= number_format($order['total_amount'], 0, ',', '.') ?>đ</strong></div>
            </div>

            <?php if (!empty($order['items'])): ?>
            <div class="order-items-summary">
                <?php foreach ($order['items'] as $item): ?>
                <div class="summary-item">
                    <span><?= htmlspecialchars($item['product_name']) ?> × <?= $item['quantity'] ?></span>
                    <span><?= number_format($item['subtotal'], 0, ',', '.') ?>đ</span>
                </div>
                <?php endforeach; ?>
            </div>
            <?php endif; ?>
        </div>
        <?php endif; ?>

        <div class="success-contact">
            <p><i class="fas fa-phone-alt"></i> Mọi thắc mắc, gọi ngay: <a href="tel:0907111106"><strong>0907 1111 06</strong></a></p>
            <p><i class="fab fa-whatsapp"></i> Zalo: <a href="https://zalo.me/0907111106">0907 1111 06</a></p>
        </div>

        <div class="success-actions">
            <a href="<?= APP_URL ?>/" class="btn btn-primary"><i class="fas fa-home"></i> Về trang chủ</a>
            <?php if (!empty($_SESSION['user_id'])): ?>
            <a href="<?= APP_URL ?>/tai-khoan" class="btn btn-outline"><i class="fas fa-list"></i> Xem đơn hàng</a>
            <?php endif; ?>
        </div>
    </div>
</div>

<div class="container">
    <nav class="breadcrumb">
        <a href="<?= APP_URL ?>/">Trang chủ</a>
        <i class="fas fa-chevron-right"></i>
        <span>Giỏ hàng</span>
    </nav>

    <h1 class="page-title"><i class="fas fa-shopping-cart"></i> Giỏ hàng của bạn</h1>

    <?php if (!empty($items)): ?>
    <div class="cart-layout">
        <div class="cart-items">
            <form method="POST" action="<?= APP_URL ?>/gio-hang/cap-nhat" id="cartForm">
                <table class="cart-table">
                    <thead>
                        <tr>
                            <th>Sản phẩm</th>
                            <th>Đơn giá</th>
                            <th>Số lượng</th>
                            <th>Thành tiền</th>
                            <th></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($items as $item): ?>
                        <tr class="cart-row" data-id="<?= $item['product']['id'] ?>">
                            <td class="cart-product">
                                <a href="<?= APP_URL ?>/chi-tiet/<?= $item['product']['slug'] ?>">
                                    <?php if (!empty($item['product']['image'])): ?>
                                        <img src="<?= APP_URL ?>/public/images/products/<?= htmlspecialchars($item['product']['image']) ?>"
                                             alt="<?= htmlspecialchars($item['product']['name']) ?>">
                                    <?php else: ?>
                                        <div class="cart-no-img"><i class="fas fa-image"></i></div>
                                    <?php endif; ?>
                                    <span><?= htmlspecialchars($item['product']['name']) ?></span>
                                </a>
                            </td>
                            <td class="cart-price"><?= number_format($item['price'], 0, ',', '.') ?>đ</td>
                            <td class="cart-qty">
                                <div class="qty-input">
                                    <button type="button" class="qty-btn qty-minus">−</button>
                                    <input type="number" name="quantity[<?= $item['product']['id'] ?>]"
                                           value="<?= $item['quantity'] ?>" min="0"
                                           max="<?= $item['product']['stock'] ?>" class="qty-field">
                                    <button type="button" class="qty-btn qty-plus">+</button>
                                </div>
                            </td>
                            <td class="cart-subtotal"><?= number_format($item['subtotal'], 0, ',', '.') ?>đ</td>
                            <td>
                                <a href="<?= APP_URL ?>/gio-hang/xoa?id=<?= $item['product']['id'] ?>"
                                   class="cart-remove" onclick="return confirm('Xóa sản phẩm này?')">
                                    <i class="fas fa-times"></i>
                                </a>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>

                <div class="cart-actions">
                    <a href="<?= APP_URL ?>/" class="btn btn-outline"><i class="fas fa-arrow-left"></i> Tiếp tục mua</a>
                    <button type="submit" class="btn btn-secondary"><i class="fas fa-sync-alt"></i> Cập nhật giỏ</button>
                    <a href="<?= APP_URL ?>/gio-hang/xoa-tat-ca" class="btn btn-outline-danger"
                       onclick="return confirm('Xóa toàn bộ giỏ hàng?')"><i class="fas fa-trash"></i> Xóa tất cả</a>
                </div>
            </form>
        </div>

        <div class="cart-summary">
            <h3>Tóm tắt đơn hàng</h3>
            <div class="summary-row">
                <span>Tạm tính (<?= count($items) ?> sản phẩm):</span>
                <strong id="cart-total"><?= number_format($total, 0, ',', '.') ?>đ</strong>
            </div>
            <div class="summary-row">
                <span>Phí vận chuyển:</span>
                <strong class="text-success">Miễn phí nội thành</strong>
            </div>
            <div class="summary-total">
                <span>Tổng cộng:</span>
                <strong class="price-big"><?= number_format($total, 0, ',', '.') ?>đ</strong>
            </div>
            <a href="<?= APP_URL ?>/dat-hang" class="btn btn-primary btn-block btn-lg">
                <i class="fas fa-credit-card"></i> Tiến hành đặt hàng
            </a>
            <div class="summary-note">
                <i class="fas fa-lock"></i> Thanh toán an toàn &amp; bảo mật
            </div>
        </div>
    </div>

    <?php else: ?>
    <div class="empty-cart">
        <i class="fas fa-shopping-cart"></i>
        <h3>Giỏ hàng của bạn đang trống</h3>
        <p>Hãy thêm sản phẩm vào giỏ để tiến hành đặt hàng</p>
        <a href="<?= APP_URL ?>/" class="btn btn-primary"><i class="fas fa-store"></i> Mua sắm ngay</a>
    </div>
    <?php endif; ?>
</div>

<script>
document.querySelectorAll('.qty-minus').forEach(btn => {
    btn.addEventListener('click', function() {
        const input = this.nextElementSibling;
        if (parseInt(input.value) > 0) input.value = parseInt(input.value) - 1;
    });
});
document.querySelectorAll('.qty-plus').forEach(btn => {
    btn.addEventListener('click', function() {
        const input = this.previousElementSibling;
        if (parseInt(input.value) < parseInt(input.max)) input.value = parseInt(input.value) + 1;
    });
});
</script>

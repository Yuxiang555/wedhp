<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($title ?? APP_NAME) ?></title>
    <meta name="description" content="Vi Tính Net - Kho vi tính giá nét tại TP.HCM. Linh kiện máy tính chính hãng, giá tốt nhất.">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Be+Vietnam+Pro:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <link rel="stylesheet" href="<?= APP_URL ?>/public/css/style.css">
</head>
<body>

<!-- TOP BAR -->
<div class="topbar">
    <div class="container">
        <div class="topbar-left">
            <span><i class="fas fa-phone-alt"></i> Hotline: <strong>0907 1111 06</strong></span>
            <span><i class="fab fa-whatsapp"></i> Zalo: <strong>0907 1111 06</strong></span>
            <span><i class="fas fa-clock"></i> 09h - 18h (CN nghỉ)</span>
        </div>
        <div class="topbar-right">
            <?php if (!empty($_SESSION['user_id'])): ?>
                <a href="<?= APP_URL ?>/tai-khoan"><i class="fas fa-user"></i> <?= htmlspecialchars($_SESSION['user_name']) ?></a>
                <a href="<?= APP_URL ?>/dang-xuat"><i class="fas fa-sign-out-alt"></i> Đăng xuất</a>
            <?php else: ?>
                <a href="<?= APP_URL ?>/dang-nhap"><i class="fas fa-sign-in-alt"></i> Đăng nhập</a>
                <a href="<?= APP_URL ?>/dang-ky"><i class="fas fa-user-plus"></i> Đăng ký</a>
            <?php endif; ?>
        </div>
    </div>
</div>

<!-- HEADER -->
<header class="header">
    <div class="container">
        <a href="<?= APP_URL ?>/" class="logo">
            <i class="fas fa-microchip"></i>
            <span>Vi<strong>Tính</strong>Net</span>
        </a>

        <form class="search-bar" method="GET" action="<?= APP_URL ?>/tim-kiem">
            <input type="text" name="q" placeholder="Tìm kiếm sản phẩm: CPU, RAM, SSD, Màn hình..."
                   value="<?= htmlspecialchars($_GET['q'] ?? '') ?>">
            <button type="submit"><i class="fas fa-search"></i></button>
        </form>

        <div class="header-actions">
            <a href="<?= APP_URL ?>/gio-hang" class="cart-btn">
                <i class="fas fa-shopping-cart"></i>
                <span class="cart-label">Giỏ hàng</span>
                <?php $cartCount = array_sum($_SESSION['cart'] ?? []); ?>
                <?php if ($cartCount > 0): ?>
                    <span class="cart-count" id="cart-count"><?= $cartCount ?></span>
                <?php else: ?>
                    <span class="cart-count" id="cart-count" style="display:none">0</span>
                <?php endif; ?>
            </a>
            <a href="tel:0907111106" class="call-btn">
                <i class="fas fa-phone-alt"></i>
                <span>Gọi ngay</span>
            </a>
        </div>
    </div>
</header>

<!-- NAVBAR -->
<nav class="navbar">
    <div class="container">
        <div class="category-menu">
            <button class="cat-toggle"><i class="fas fa-th-large"></i> Danh mục sản phẩm</button>
            <ul class="cat-dropdown">
                <?php
                $navCategoryModel = new CategoryModel();
                $navCategories = $navCategoryModel->getAll();
                foreach ($navCategories as $cat):
                ?>
                <li>
                    <a href="<?= APP_URL ?>/san-pham/<?= $cat['slug'] ?>">
                        <i class="fas <?= $cat['icon'] ?? 'fa-tag' ?>"></i>
                        <?= htmlspecialchars($cat['name']) ?>
                    </a>
                </li>
                <?php endforeach; ?>
            </ul>
        </div>
        <ul class="main-menu">
            <li><a href="<?= APP_URL ?>/">Trang chủ</a></li>
            <li><a href="<?= APP_URL ?>/san-pham/laptop">Laptop</a></li>
            <li><a href="<?= APP_URL ?>/san-pham/pc-desktop">PC Desktop</a></li>
            <li><a href="<?= APP_URL ?>/san-pham/man-hinh">Màn hình</a></li>
            <li><a href="<?= APP_URL ?>/san-pham/linh-kien-khac">Linh kiện</a></li>
            <li><a href="<?= APP_URL ?>/lien-he">Liên hệ</a></li>
        </ul>
    </div>
</nav>

<!-- MAIN CONTENT -->
<main class="main-content">
    <?php require $content; ?>
</main>

<!-- FOOTER -->
<footer class="footer">
    <div class="container">
        <div class="footer-grid">
            <div class="footer-col">
                <h3><i class="fas fa-microchip"></i> Vi Tính Net</h3>
                <p>Kho vi tính giá nét - Chuyên cung cấp linh kiện máy tính chính hãng, giá tốt nhất tại TP.HCM.</p>
                <div class="footer-social">
                    <a href="#"><i class="fab fa-facebook-f"></i></a>
                    <a href="#"><i class="fab fa-youtube"></i></a>
                    <a href="#"><i class="fab fa-tiktok"></i></a>
                </div>
            </div>
            <div class="footer-col">
                <h4>Danh mục</h4>
                <ul>
                    <li><a href="<?= APP_URL ?>/san-pham/laptop">Laptop</a></li>
                    <li><a href="<?= APP_URL ?>/san-pham/cpu">CPU / Vi xử lý</a></li>
                    <li><a href="<?= APP_URL ?>/san-pham/ram">RAM</a></li>
                    <li><a href="<?= APP_URL ?>/san-pham/o-cung">Ổ cứng SSD/HDD</a></li>
                    <li><a href="<?= APP_URL ?>/san-pham/card-man-hinh">Card màn hình</a></li>
                    <li><a href="<?= APP_URL ?>/san-pham/man-hinh">Màn hình</a></li>
                </ul>
            </div>
            <div class="footer-col">
                <h4>Hỗ trợ</h4>
                <ul>
                    <li><a href="<?= APP_URL ?>/lien-he">Liên hệ</a></li>
                    <li><a href="<?= APP_URL ?>/chinh-sach-bao-hanh">Chính sách bảo hành</a></li>
                    <li><a href="<?= APP_URL ?>/chinh-sach-doi-tra">Chính sách đổi trả</a></li>
                    <li><a href="<?= APP_URL ?>/chinh-sach-van-chuyen">Vận chuyển</a></li>
                </ul>
            </div>
            <div class="footer-col">
                <h4>Liên hệ</h4>
                <ul class="contact-list">
                    <li><i class="fas fa-map-marker-alt"></i> 19/6/24 Hoàng Xuân Nhị, P.Tân Phú, TP.HCM</li>
                    <li><i class="fas fa-phone-alt"></i> <a href="tel:0907111106">0907 1111 06</a></li>
                    <li><i class="fab fa-whatsapp"></i> Zalo: <a href="https://zalo.me/0907111106">0907 1111 06</a></li>
                    <li><i class="fas fa-clock"></i> 09h - 18h (Chủ Nhật nghỉ)</li>
                </ul>
            </div>
        </div>
        <div class="footer-bottom">
            <p>&copy; <?= date('Y') ?> Vi Tính Net. Thiết kế & phát triển tại TP.HCM.</p>
        </div>
    </div>
</footer>

<!-- ZALO FLOAT -->
<a href="https://zalo.me/0907111106" class="zalo-float" target="_blank" title="Chat Zalo">
    <i class="fab fa-whatsapp"></i>
</a>
<a href="tel:0907111106" class="phone-float" title="Gọi ngay">
    <i class="fas fa-phone-alt"></i>
</a>

<script>window.APP_URL = '<?= APP_URL ?>';</script>
<script src="<?= APP_URL ?>/public/js/main.js"></script>
</body>
</html>

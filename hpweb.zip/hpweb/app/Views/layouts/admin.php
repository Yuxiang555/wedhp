<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($title ?? 'Admin') ?> | Vi Tính Net</title>
    <link href="https://fonts.googleapis.com/css2?family=Be+Vietnam+Pro:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <link rel="stylesheet" href="<?= APP_URL ?>/public/css/admin.css">
</head>
<body class="admin-body">

<div class="admin-wrapper">
    <!-- SIDEBAR -->
    <aside class="admin-sidebar" id="sidebar">
        <div class="sidebar-logo">
            <i class="fas fa-microchip"></i>
            <span>Admin Panel</span>
        </div>
        <nav class="sidebar-nav">
            <a href="<?= APP_URL ?>/admin" class="<?= (strpos($_SERVER['REQUEST_URI'], '/admin') !== false && !strpos($_SERVER['REQUEST_URI'], '/admin/')) ? 'active' : '' ?>">
                <i class="fas fa-tachometer-alt"></i> Dashboard
            </a>
            <a href="<?= APP_URL ?>/admin/san-pham" class="<?= strpos($_SERVER['REQUEST_URI'], '/admin/san-pham') !== false ? 'active' : '' ?>">
                <i class="fas fa-box"></i> Sản phẩm
            </a>
            <a href="<?= APP_URL ?>/admin/danh-muc" class="<?= strpos($_SERVER['REQUEST_URI'], '/admin/danh-muc') !== false ? 'active' : '' ?>">
                <i class="fas fa-tags"></i> Danh mục
            </a>
            <a href="<?= APP_URL ?>/admin/don-hang" class="<?= strpos($_SERVER['REQUEST_URI'], '/admin/don-hang') !== false ? 'active' : '' ?>">
                <i class="fas fa-shopping-bag"></i> Đơn hàng
            </a>
            <a href="<?= APP_URL ?>/admin/lien-he" class="<?= strpos($_SERVER['REQUEST_URI'], '/admin/lien-he') !== false ? 'active' : '' ?>">
                <i class="fas fa-envelope"></i> Tin nhắn
            </a>
            <a href="<?= APP_URL ?>/admin/cai-dat" class="<?= strpos($_SERVER['REQUEST_URI'], '/admin/cai-dat') !== false ? 'active' : '' ?>">
                <i class="fas fa-cog"></i> Cài đặt
            </a>
            <hr>
            <a href="<?= APP_URL ?>/" target="_blank"><i class="fas fa-eye"></i> Xem website</a>
            <a href="<?= APP_URL ?>/dang-xuat"><i class="fas fa-sign-out-alt"></i> Đăng xuất</a>
        </nav>
    </aside>

    <!-- MAIN -->
    <div class="admin-main">
        <header class="admin-header">
            <button class="sidebar-toggle" id="sidebarToggle"><i class="fas fa-bars"></i></button>
            <h1 class="admin-page-title"><?= htmlspecialchars($title ?? '') ?></h1>
            <div class="admin-user">
                <i class="fas fa-user-circle"></i>
                <span><?= htmlspecialchars($_SESSION['user_name'] ?? 'Admin') ?></span>
            </div>
        </header>

        <div class="admin-content">
            <?php require $content; ?>
        </div>
    </div>
</div>

<script src="<?= APP_URL ?>/public/js/admin.js"></script>
</body>
</html>

<div class="container">
    <nav class="breadcrumb">
        <a href="<?= APP_URL ?>/">Trang chủ</a>
        <i class="fas fa-chevron-right"></i>
        <span><?= htmlspecialchars($category['name']) ?></span>
    </nav>

    <div class="catalog-layout">
        <!-- SIDEBAR FILTER -->
        <aside class="catalog-sidebar">
            <h3><i class="fas fa-tags"></i> Danh mục</h3>
            <ul class="sidebar-categories">
                <?php foreach ($categories as $cat): ?>
                <li class="<?= $cat['id'] == $category['id'] ? 'active' : '' ?>">
                    <a href="<?= APP_URL ?>/san-pham/<?= $cat['slug'] ?>">
                        <i class="fas <?= $cat['icon'] ?? 'fa-tag' ?>"></i>
                        <?= htmlspecialchars($cat['name']) ?>
                        <span>(<?= $cat['product_count'] ?>)</span>
                    </a>
                </li>
                <?php endforeach; ?>
            </ul>
        </aside>

        <!-- PRODUCTS -->
        <div class="catalog-main">
            <div class="catalog-header">
                <h1><?= htmlspecialchars($category['name']) ?>
                    <span class="count">(<?= $totalItems ?> sản phẩm)</span>
                </h1>
                <div class="sort-bar">
                    <span>Sắp xếp:</span>
                    <a href="?sort=newest" class="<?= $sort === 'newest' ? 'active' : '' ?>">Mới nhất</a>
                    <a href="?sort=price_asc" class="<?= $sort === 'price_asc' ? 'active' : '' ?>">Giá tăng</a>
                    <a href="?sort=price_desc" class="<?= $sort === 'price_desc' ? 'active' : '' ?>">Giá giảm</a>
                </div>
            </div>

            <?php if (empty($products)): ?>
                <div class="empty-state">
                    <i class="fas fa-box-open"></i>
                    <p>Chưa có sản phẩm trong danh mục này</p>
                    <a href="<?= APP_URL ?>/" class="btn btn-primary">Về trang chủ</a>
                </div>
            <?php else: ?>
                <div class="product-grid">
                    <?php foreach ($products as $product): ?>
                    <?php include __DIR__ . '/_card.php'; ?>
                    <?php endforeach; ?>
                </div>

                <!-- PAGINATION -->
                <?php if ($totalPages > 1): ?>
                <div class="pagination">
                    <?php if ($page > 1): ?>
                        <a href="?page=<?= $page - 1 ?>&sort=<?= $sort ?>" class="page-btn"><i class="fas fa-chevron-left"></i></a>
                    <?php endif; ?>
                    <?php for ($i = max(1, $page - 2); $i <= min($totalPages, $page + 2); $i++): ?>
                        <a href="?page=<?= $i ?>&sort=<?= $sort ?>" class="page-btn <?= $i === $page ? 'active' : '' ?>"><?= $i ?></a>
                    <?php endfor; ?>
                    <?php if ($page < $totalPages): ?>
                        <a href="?page=<?= $page + 1 ?>&sort=<?= $sort ?>" class="page-btn"><i class="fas fa-chevron-right"></i></a>
                    <?php endif; ?>
                </div>
                <?php endif; ?>
            <?php endif; ?>
        </div>
    </div>
</div>

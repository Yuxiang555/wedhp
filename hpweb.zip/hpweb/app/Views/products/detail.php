<?php
$currentPrice = $product['sale_price'] ?: $product['price'];
$hasDiscount  = !empty($product['sale_price']) && $product['sale_price'] < $product['price'];
$discountPct  = $hasDiscount ? round((1 - $product['sale_price'] / $product['price']) * 100) : 0;
?>
<div class="container">
    <!-- BREADCRUMB -->
    <nav class="breadcrumb">
        <a href="<?= APP_URL ?>/">Trang chủ</a>
        <i class="fas fa-chevron-right"></i>
        <a href="<?= APP_URL ?>/san-pham/<?= $product['category_slug'] ?>"><?= htmlspecialchars($product['category_name']) ?></a>
        <i class="fas fa-chevron-right"></i>
        <span><?= htmlspecialchars($product['name']) ?></span>
    </nav>

    <div class="product-detail">
        <!-- GALLERY -->
        <div class="product-gallery">
            <div class="gallery-main" id="galleryMain">
                <?php if (!empty($images[0])): ?>
                    <img src="<?= APP_URL ?>/public/images/products/<?= htmlspecialchars($images[0]) ?>"
                         alt="<?= htmlspecialchars($product['name']) ?>" id="mainImage">
                <?php else: ?>
                    <div class="gallery-placeholder"><i class="fas fa-image"></i></div>
                <?php endif; ?>
            </div>
            <?php if (count($images) > 1): ?>
            <div class="gallery-thumbs">
                <?php foreach ($images as $i => $img): ?>
                <img src="<?= APP_URL ?>/public/images/products/<?= htmlspecialchars($img) ?>"
                     alt="<?= $i + 1 ?>"
                     class="thumb <?= $i === 0 ? 'active' : '' ?>"
                     onclick="switchImage(this, '<?= APP_URL ?>/public/images/products/<?= htmlspecialchars($img) ?>')">
                <?php endforeach; ?>
            </div>
            <?php endif; ?>
        </div>

        <!-- INFO -->
        <div class="product-detail-info">
            <?php if (!empty($product['brand_name'])): ?>
                <span class="product-brand-tag"><?= htmlspecialchars($product['brand_name']) ?></span>
            <?php endif; ?>

            <h1 class="product-detail-name"><?= htmlspecialchars($product['name']) ?></h1>

            <div class="product-meta">
                <?php if (!empty($product['sku'])): ?>
                    <span>Mã SP: <strong><?= htmlspecialchars($product['sku']) ?></strong></span>
                <?php endif; ?>
                <span>Tình trạng: <strong class="<?= $product['stock'] > 0 ? 'text-success' : 'text-danger' ?>">
                    <?= $product['stock'] > 0 ? 'Còn hàng (' . $product['stock'] . ')' : 'Hết hàng' ?>
                </strong></span>
                <span>Lượt xem: <strong><?= number_format($product['view_count']) ?></strong></span>
            </div>

            <div class="product-detail-price">
                <span class="price-main"><?= number_format($currentPrice, 0, ',', '.') ?>đ</span>
                <?php if ($hasDiscount): ?>
                    <span class="price-old-detail"><?= number_format($product['price'], 0, ',', '.') ?>đ</span>
                    <span class="discount-badge">Tiết kiệm <?= $discountPct ?>%</span>
                <?php endif; ?>
            </div>

            <?php if ($product['stock'] > 0): ?>
            <form class="add-to-cart-form" method="POST" action="<?= APP_URL ?>/gio-hang/them">
                <input type="hidden" name="product_id" value="<?= $product['id'] ?>">
                <div class="qty-control">
                    <label>Số lượng:</label>
                    <div class="qty-input">
                        <button type="button" class="qty-btn" id="qtyMinus">−</button>
                        <input type="number" name="quantity" value="1" min="1" max="<?= $product['stock'] ?>" id="qtyInput">
                        <button type="button" class="qty-btn" id="qtyPlus">+</button>
                    </div>
                </div>
                <div class="detail-actions">
                    <button type="submit" class="btn btn-primary btn-lg">
                        <i class="fas fa-cart-plus"></i> Thêm vào giỏ
                    </button>
                    <a href="<?= APP_URL ?>/dat-hang" class="btn btn-danger btn-lg">
                        <i class="fas fa-bolt"></i> Mua ngay
                    </a>
                </div>
            </form>
            <?php else: ?>
                <div class="out-of-stock-notice">
                    <i class="fas fa-exclamation-circle"></i> Sản phẩm tạm hết hàng.
                    <a href="tel:0907111106">Gọi 0907 1111 06</a> để đặt trước.
                </div>
            <?php endif; ?>

            <div class="product-guarantees">
                <div><i class="fas fa-shield-alt"></i> Hàng chính hãng 100%</div>
                <div><i class="fas fa-undo-alt"></i> Đổi trả trong 7 ngày</div>
                <div><i class="fas fa-wrench"></i> Bảo hành theo hãng</div>
                <div><i class="fas fa-motorcycle"></i> Giao hàng nhanh nội thành</div>
            </div>
        </div>
    </div>

    <!-- TABS: MÔ TẢ / THÔNG SỐ -->
    <div class="product-tabs">
        <div class="tab-headers">
            <button class="tab-btn active" data-tab="desc">Mô tả sản phẩm</button>
            <?php if (!empty($product['specs'])): ?>
            <button class="tab-btn" data-tab="specs">Thông số kỹ thuật</button>
            <?php endif; ?>
        </div>
        <div class="tab-content active" id="tab-desc">
            <?php if (!empty($product['description'])): ?>
                <div class="product-description"><?= nl2br(htmlspecialchars($product['description'])) ?></div>
            <?php else: ?>
                <p class="text-muted">Chưa có mô tả chi tiết.</p>
            <?php endif; ?>
        </div>
        <?php if (!empty($product['specs'])): ?>
        <div class="tab-content" id="tab-specs">
            <?= nl2br(htmlspecialchars($product['specs'])) ?>
        </div>
        <?php endif; ?>
    </div>

    <!-- SẢN PHẨM LIÊN QUAN -->
    <?php if (!empty($related)): ?>
    <section class="section">
        <h2 class="section-title"><i class="fas fa-sync-alt"></i> Sản phẩm liên quan</h2>
        <div class="product-grid">
            <?php foreach ($related as $product): ?>
            <?php include __DIR__ . '/_card.php'; ?>
            <?php endforeach; ?>
        </div>
    </section>
    <?php endif; ?>
</div>

<script>
function switchImage(thumb, src) {
    document.getElementById('mainImage').src = src;
    document.querySelectorAll('.thumb').forEach(t => t.classList.remove('active'));
    thumb.classList.add('active');
}
document.getElementById('qtyMinus')?.addEventListener('click', () => {
    const i = document.getElementById('qtyInput');
    if (parseInt(i.value) > 1) i.value = parseInt(i.value) - 1;
});
document.getElementById('qtyPlus')?.addEventListener('click', () => {
    const i = document.getElementById('qtyInput');
    if (parseInt(i.value) < parseInt(i.max)) i.value = parseInt(i.value) + 1;
});
document.querySelectorAll('.tab-btn').forEach(btn => {
    btn.addEventListener('click', () => {
        document.querySelectorAll('.tab-btn, .tab-content').forEach(el => el.classList.remove('active'));
        btn.classList.add('active');
        document.getElementById('tab-' + btn.dataset.tab).classList.add('active');
    });
});
</script>

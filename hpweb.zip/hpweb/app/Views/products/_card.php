<?php
$currentPrice  = $product['sale_price'] ?: $product['price'];
$hasDiscount   = !empty($product['sale_price']) && $product['sale_price'] < $product['price'];
$discountPct   = $hasDiscount ? round((1 - $product['sale_price'] / $product['price']) * 100) : 0;
?>
<div class="product-card">
    <?php if ($hasDiscount): ?>
        <span class="badge badge-sale">-<?= $discountPct ?>%</span>
    <?php endif; ?>
    <?php if ($product['is_new']): ?>
        <span class="badge badge-new">MỚI</span>
    <?php endif; ?>

    <a href="<?= APP_URL ?>/chi-tiet/<?= $product['slug'] ?>" class="product-image">
        <?php if (!empty($product['image'])): ?>
            <img src="<?= APP_URL ?>/public/images/products/<?= htmlspecialchars($product['image']) ?>"
                 alt="<?= htmlspecialchars($product['name']) ?>" loading="lazy">
        <?php else: ?>
            <div class="product-no-image"><i class="fas fa-image"></i></div>
        <?php endif; ?>
    </a>

    <div class="product-info">
        <?php if (!empty($product['brand_name'])): ?>
            <span class="product-brand"><?= htmlspecialchars($product['brand_name']) ?></span>
        <?php endif; ?>
        <h3 class="product-name">
            <a href="<?= APP_URL ?>/chi-tiet/<?= $product['slug'] ?>">
                <?= htmlspecialchars($product['name']) ?>
            </a>
        </h3>
        <div class="product-price">
            <span class="price-current"><?= number_format($currentPrice, 0, ',', '.') ?>đ</span>
            <?php if ($hasDiscount): ?>
                <span class="price-old"><?= number_format($product['price'], 0, ',', '.') ?>đ</span>
            <?php endif; ?>
        </div>
        <div class="product-actions">
            <button class="btn btn-cart btn-add-cart"
                    data-id="<?= $product['id'] ?>"
                    <?= $product['stock'] <= 0 ? 'disabled' : '' ?>>
                <i class="fas fa-cart-plus"></i>
                <?= $product['stock'] <= 0 ? 'Hết hàng' : 'Thêm vào giỏ' ?>
            </button>
            <a href="<?= APP_URL ?>/chi-tiet/<?= $product['slug'] ?>" class="btn btn-detail">
                <i class="fas fa-eye"></i>
            </a>
        </div>
    </div>
</div>

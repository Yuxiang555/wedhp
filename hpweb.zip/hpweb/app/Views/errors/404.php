<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>404 - Không tìm thấy trang</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <style>
        body { font-family: 'Be Vietnam Pro', sans-serif; display: flex; align-items: center; justify-content: center; min-height: 100vh; background: #f5f7fa; margin: 0; }
        .err { text-align: center; padding: 2rem; }
        .err h1 { font-size: 6rem; color: #e63946; margin: 0; }
        .err h2 { font-size: 1.5rem; color: #333; }
        .err p { color: #666; margin: 1rem 0 2rem; }
        .err a { background: #e63946; color: #fff; padding: .75rem 2rem; border-radius: 6px; text-decoration: none; }
        .err a:hover { background: #c1121f; }
    </style>
</head>
<body>
    <div class="err">
        <i class="fas fa-exclamation-circle" style="font-size:4rem;color:#e63946;"></i>
        <h1>404</h1>
        <h2>Trang không tồn tại</h2>
        <p>Trang bạn tìm kiếm đã bị xóa hoặc không tồn tại.</p>
        <a href="<?= defined('APP_URL') ? APP_URL : '/' ?>/"><i class="fas fa-home"></i> Về trang chủ</a>
    </div>
</body>
</html>

<div class="container">
    <nav class="breadcrumb">
        <a href="<?= APP_URL ?>/">Trang chủ</a>
        <i class="fas fa-chevron-right"></i>
        <span>Liên hệ</span>
    </nav>

    <h1 class="page-title"><i class="fas fa-envelope"></i> Liên hệ với chúng tôi</h1>

    <?php if (!empty($flash)): ?>
    <div class="alert alert-<?= $flash['type'] ?>"><?= $flash['message'] ?></div>
    <?php endif; ?>

    <div class="contact-layout">
        <!-- THÔNG TIN LIÊN HỆ -->
        <div class="contact-info">
            <div class="info-card">
                <h3>Thông tin cửa hàng</h3>
                <ul class="info-list">
                    <li>
                        <i class="fas fa-map-marker-alt"></i>
                        <div>
                            <strong>Địa chỉ</strong>
                            <span><?= htmlspecialchars($settings['site_address'] ?? '') ?></span>
                        </div>
                    </li>
                    <li>
                        <i class="fas fa-phone-alt"></i>
                        <div>
                            <strong>Điện thoại / Zalo</strong>
                            <a href="tel:<?= preg_replace('/\s+/', '', $settings['site_phone'] ?? '') ?>">
                                <?= htmlspecialchars($settings['site_phone'] ?? '') ?> (Ms An)
                            </a>
                        </div>
                    </li>
                    <li>
                        <i class="fas fa-envelope"></i>
                        <div>
                            <strong>Email</strong>
                            <a href="mailto:<?= htmlspecialchars($settings['site_email'] ?? '') ?>">
                                <?= htmlspecialchars($settings['site_email'] ?? '') ?>
                            </a>
                        </div>
                    </li>
                    <li>
                        <i class="fas fa-clock"></i>
                        <div>
                            <strong>Giờ làm việc</strong>
                            <span><?= htmlspecialchars($settings['site_hours'] ?? '') ?></span>
                        </div>
                    </li>
                </ul>

                <div class="contact-social">
                    <a href="<?= htmlspecialchars($settings['site_facebook'] ?? '#') ?>" target="_blank" class="social-btn fb">
                        <i class="fab fa-facebook-f"></i> Facebook
                    </a>
                    <a href="https://zalo.me/<?= preg_replace('/\s+/', '', $settings['site_zalo'] ?? '') ?>"
                       target="_blank" class="social-btn zalo">
                        <i class="fab fa-whatsapp"></i> Zalo
                    </a>
                </div>
            </div>

            <!-- GOOGLE MAP -->
            <div class="map-container">
                <iframe
                    src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3919.3!2d106.636!3d10.772!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x0!2zSG_DoG5nIFh1w6JuIE5oacOq!5e0!3m2!1svi!2svn!4v1"
                    width="100%" height="250" style="border:0;" allowfullscreen="" loading="lazy">
                </iframe>
            </div>
        </div>

        <!-- FORM LIÊN HỆ -->
        <div class="contact-form-wrap">
            <h3>Gửi tin nhắn cho chúng tôi</h3>
            <form method="POST" action="<?= APP_URL ?>/lien-he/gui" class="contact-form">
                <div class="form-row">
                    <div class="form-group">
                        <label>Họ và tên <span class="required">*</span></label>
                        <input type="text" name="name" required placeholder="Nguyễn Văn A">
                    </div>
                    <div class="form-group">
                        <label>Số điện thoại</label>
                        <input type="tel" name="phone" placeholder="09xxxxxxxx">
                    </div>
                </div>
                <div class="form-group">
                    <label>Email</label>
                    <input type="email" name="email" placeholder="email@example.com">
                </div>
                <div class="form-group">
                    <label>Chủ đề</label>
                    <select name="subject">
                        <option value="">-- Chọn chủ đề --</option>
                        <option>Hỏi về sản phẩm</option>
                        <option>Hỗ trợ kỹ thuật</option>
                        <option>Khiếu nại / Bảo hành</option>
                        <option>Hợp tác kinh doanh</option>
                        <option>Khác</option>
                    </select>
                </div>
                <div class="form-group">
                    <label>Nội dung <span class="required">*</span></label>
                    <textarea name="message" required rows="5" placeholder="Nhập nội dung tin nhắn..."></textarea>
                </div>
                <button type="submit" class="btn btn-primary btn-block">
                    <i class="fas fa-paper-plane"></i> Gửi tin nhắn
                </button>
            </form>
        </div>
    </div>
</div>

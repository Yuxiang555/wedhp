-- Database: vitinhnet
CREATE DATABASE IF NOT EXISTS vitinhnet CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE vitinhnet;

-- Bảng danh mục sản phẩm
CREATE TABLE IF NOT EXISTS categories (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    slug VARCHAR(100) NOT NULL UNIQUE,
    icon VARCHAR(100) DEFAULT NULL,
    parent_id INT DEFAULT NULL,
    sort_order INT DEFAULT 0,
    status TINYINT(1) DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (parent_id) REFERENCES categories(id) ON DELETE SET NULL
) ENGINE=InnoDB;

-- Bảng thương hiệu
CREATE TABLE IF NOT EXISTS brands (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    slug VARCHAR(100) NOT NULL UNIQUE,
    logo VARCHAR(255) DEFAULT NULL,
    status TINYINT(1) DEFAULT 1
) ENGINE=InnoDB;

-- Bảng sản phẩm
CREATE TABLE IF NOT EXISTS products (
    id INT AUTO_INCREMENT PRIMARY KEY,
    category_id INT NOT NULL,
    brand_id INT DEFAULT NULL,
    name VARCHAR(255) NOT NULL,
    slug VARCHAR(255) NOT NULL UNIQUE,
    sku VARCHAR(100) DEFAULT NULL,
    description TEXT,
    specs TEXT,
    price DECIMAL(15,0) NOT NULL DEFAULT 0,
    sale_price DECIMAL(15,0) DEFAULT NULL,
    stock INT DEFAULT 0,
    image VARCHAR(255) DEFAULT NULL,
    images TEXT DEFAULT NULL,
    is_featured TINYINT(1) DEFAULT 0,
    is_new TINYINT(1) DEFAULT 1,
    status TINYINT(1) DEFAULT 1,
    view_count INT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (category_id) REFERENCES categories(id),
    FOREIGN KEY (brand_id) REFERENCES brands(id) ON DELETE SET NULL
) ENGINE=InnoDB;

-- Bảng banners
CREATE TABLE IF NOT EXISTS banners (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(255),
    image VARCHAR(255) NOT NULL,
    link VARCHAR(255) DEFAULT '#',
    sort_order INT DEFAULT 0,
    status TINYINT(1) DEFAULT 1
) ENGINE=InnoDB;

-- Bảng users (khách hàng)
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(150) NOT NULL UNIQUE,
    phone VARCHAR(20) DEFAULT NULL,
    password VARCHAR(255) NOT NULL,
    address TEXT DEFAULT NULL,
    avatar VARCHAR(255) DEFAULT NULL,
    role ENUM('admin','customer') DEFAULT 'customer',
    status TINYINT(1) DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- Bảng đơn hàng
CREATE TABLE IF NOT EXISTS orders (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT DEFAULT NULL,
    order_code VARCHAR(50) NOT NULL UNIQUE,
    customer_name VARCHAR(100) NOT NULL,
    customer_phone VARCHAR(20) NOT NULL,
    customer_email VARCHAR(150) DEFAULT NULL,
    shipping_address TEXT NOT NULL,
    note TEXT DEFAULT NULL,
    total_amount DECIMAL(15,0) NOT NULL DEFAULT 0,
    status ENUM('pending','confirmed','shipping','delivered','cancelled') DEFAULT 'pending',
    payment_method ENUM('cod','bank_transfer') DEFAULT 'cod',
    payment_status TINYINT(1) DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB;

-- Bảng chi tiết đơn hàng
CREATE TABLE IF NOT EXISTS order_items (
    id INT AUTO_INCREMENT PRIMARY KEY,
    order_id INT NOT NULL,
    product_id INT NOT NULL,
    product_name VARCHAR(255) NOT NULL,
    product_image VARCHAR(255) DEFAULT NULL,
    price DECIMAL(15,0) NOT NULL,
    quantity INT NOT NULL DEFAULT 1,
    subtotal DECIMAL(15,0) NOT NULL,
    FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE,
    FOREIGN KEY (product_id) REFERENCES products(id)
) ENGINE=InnoDB;

-- Bảng liên hệ
CREATE TABLE IF NOT EXISTS contacts (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    phone VARCHAR(20) DEFAULT NULL,
    email VARCHAR(150) DEFAULT NULL,
    subject VARCHAR(255) DEFAULT NULL,
    message TEXT NOT NULL,
    is_read TINYINT(1) DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- Bảng settings
CREATE TABLE IF NOT EXISTS settings (
    id INT AUTO_INCREMENT PRIMARY KEY,
    key_name VARCHAR(100) NOT NULL UNIQUE,
    value TEXT,
    group_name VARCHAR(50) DEFAULT 'general'
) ENGINE=InnoDB;

-- ===================== DỮ LIỆU MẪU =====================

-- Admin mặc định (password: admin123)
INSERT INTO users (name, email, phone, password, role) VALUES
('Admin', 'admin@vitinhnet.com', '0907111106', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'admin');

-- Danh mục
INSERT INTO categories (name, slug, icon, sort_order) VALUES
('Laptop', 'laptop', 'fa-laptop', 1),
('PC Desktop', 'pc-desktop', 'fa-desktop', 2),
('Màn hình', 'man-hinh', 'fa-tv', 3),
('CPU / Bộ vi xử lý', 'cpu', 'fa-microchip', 4),
('RAM / Bộ nhớ', 'ram', 'fa-memory', 5),
('Ổ cứng SSD / HDD', 'o-cung', 'fa-hdd', 6),
('Card màn hình', 'card-man-hinh', 'fa-th-large', 7),
('Mainboard', 'mainboard', 'fa-server', 8),
('Nguồn máy tính', 'nguon', 'fa-plug', 9),
('Bàn phím', 'ban-phim', 'fa-keyboard', 10),
('Chuột', 'chuot', 'fa-mouse', 11),
('Tai nghe', 'tai-nghe', 'fa-headphones', 12),
('Thiết bị mạng', 'thiet-bi-mang', 'fa-wifi', 13),
('Linh kiện khác', 'linh-kien-khac', 'fa-tools', 14);

-- Thương hiệu
INSERT INTO brands (name, slug) VALUES
('Intel', 'intel'),
('AMD', 'amd'),
('ASUS', 'asus'),
('MSI', 'msi'),
('Gigabyte', 'gigabyte'),
('Samsung', 'samsung'),
('Kingston', 'kingston'),
('Western Digital', 'western-digital'),
('Seagate', 'seagate'),
('Corsair', 'corsair'),
('NVIDIA', 'nvidia'),
('Dell', 'dell'),
('HP', 'hp'),
('Acer', 'acer'),
('Lenovo', 'lenovo');

-- Sản phẩm mẫu
INSERT INTO products (category_id, brand_id, name, slug, sku, description, price, sale_price, stock, is_featured, is_new) VALUES
(4, 1, 'CPU Intel Core i5-13400F Tray', 'cpu-intel-core-i5-13400f-tray', 'CPU-I513400F', 'CPU Intel Core i5-13400F, 10 nhân 16 luồng, xung nhịp 2.5GHz boost 4.6GHz, TDP 65W, socket LGA1700.', 3890000, 3590000, 50, 1, 1),
(4, 2, 'CPU AMD Ryzen 5 7600X Box', 'cpu-amd-ryzen-5-7600x', 'CPU-R57600X', 'AMD Ryzen 5 7600X, 6 nhân 12 luồng, xung nhịp 4.7GHz boost 5.3GHz, TDP 105W, socket AM5.', 4890000, 4490000, 30, 1, 1),
(5, 7, 'RAM Kingston Fury Beast 16GB DDR4 3200MHz', 'ram-kingston-fury-beast-16gb-ddr4-3200', 'RAM-KF16D4', 'RAM Desktop Kingston Fury Beast 16GB (1x16GB) DDR4 Bus 3200MHz CL16, tản nhiệt nhôm, hỗ trợ XMP.', 890000, 790000, 100, 1, 1),
(6, 8, 'SSD Western Digital SN580 500GB NVMe M.2', 'ssd-wd-sn580-500gb-nvme', 'SSD-WD500', 'SSD WD Blue SN580 500GB PCIe Gen4 NVMe M.2 2280, đọc 4000 MB/s, ghi 3600 MB/s.', 1290000, 1090000, 80, 1, 1),
(3, 3, 'Màn hình ASUS TUF Gaming VG249Q3A 23.8 inch 180Hz', 'man-hinh-asus-tuf-vg249q3a', 'MON-ASUS249', 'Màn hình ASUS TUF VG249Q3A 23.8 inch Full HD IPS 180Hz 1ms, Adaptive Sync, HDMI, DisplayPort.', 4290000, 3990000, 25, 1, 1),
(7, 11, 'VGA ASUS Dual RTX 4060 OC 8GB GDDR6', 'vga-asus-dual-rtx-4060-oc-8gb', 'VGA-RTX4060', 'Card màn hình ASUS Dual GeForce RTX 4060 OC Edition 8GB GDDR6, DLSS 3, ray tracing, 2 fan.', 8290000, 7890000, 20, 1, 1),
(8, 3, 'Mainboard ASUS PRIME B660M-A WIFI D4', 'mainboard-asus-prime-b660m-a-wifi-d4', 'MB-B660MA', 'Bo mạch chủ ASUS PRIME B660M-A WIFI DDR4, socket LGA1700, mATX, 2x M.2, WiFi 6, Bluetooth 5.2.', 3490000, 3190000, 15, 0, 1),
(9, 10, 'Nguồn Corsair CV650 650W 80 Plus Bronze', 'nguon-corsair-cv650-650w', 'PSU-CV650', 'Nguồn máy tính Corsair CV650 650W 80 Plus Bronze, cáp cố định, bảo vệ quá áp/quá tải/ngắn mạch.', 1590000, 1390000, 40, 0, 1),
(10, 3, 'Bàn phím cơ ASUS ROG Strix Scope RX TKL', 'ban-phim-asus-rog-strix-scope-rx-tkl', 'KB-ROGRX', 'Bàn phím cơ ASUS ROG Strix Scope RX TKL, switch ROG RX Red, tenkeyless, RGB Aura Sync, USB-C.', 2890000, 2690000, 35, 1, 1),
(11, 3, 'Chuột ASUS ROG Keris II Ace Wireless', 'chuot-asus-rog-keris-ii-ace', 'MS-KERISIIA', 'Chuột không dây ASUS ROG Keris II Ace, sensor 36000 DPI, 54g siêu nhẹ, kết nối 2.4GHz/BT/USB.', 2190000, 1990000, 45, 1, 0);

-- Settings
INSERT INTO settings (key_name, value, group_name) VALUES
('site_name', 'Vi Tính Net - Kho Vi Tính Giá Nét', 'general'),
('site_phone', '0907 1111 06', 'general'),
('site_zalo', '0907 1111 06', 'general'),
('site_email', 'info@vitinhnet.com', 'general'),
('site_address', '19/6/24 Hoàng Xuân Nhị, Phường Tân Phú, TP. HCM', 'general'),
('site_hours', 'Từ 09h - 18h mỗi ngày (Chủ Nhật nghỉ)', 'general'),
('site_facebook', 'https://facebook.com/vitinhnet', 'social'),
('bank_name', 'Vietcombank', 'payment'),
('bank_account', '1234567890', 'payment'),
('bank_owner', 'VI TINH NET', 'payment');

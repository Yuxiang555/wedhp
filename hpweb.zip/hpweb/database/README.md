# VI TÍNH NET - Database & Thông tin đăng nhập

## Import Database

1. Mở `http://localhost/phpmyadmin`
2. Tạo database tên `vitinhnet` (hoặc bỏ qua, file SQL tự tạo)
3. Chọn tab **Import** → chọn file `vitinhnet.sql` → **Go**

---

## Tài khoản đăng nhập

### Admin Panel (`/admin`)
| | |
|---|---|
| **URL** | http://localhost/hpweb/admin |
| **Email** | admin@vitinhnet.com |
| **Mật khẩu** | password |

### Khách hàng (tạo mới qua `/dang-ky`)
| | |
|---|---|
| **URL đăng ký** | http://localhost/hpweb/dang-ky |
| **URL đăng nhập** | http://localhost/hpweb/dang-nhap |

---

## Cấu hình database (`config/database.php`)

| | |
|---|---|
| **Host** | localhost |
| **Database** | vitinhnet |
| **Username** | root |
| **Password** | *(để trống)* |

---

## Các bảng trong database

| Bảng | Mô tả | Dữ liệu mẫu |
|------|-------|-------------|
| `users` | Tài khoản người dùng | 1 admin |
| `categories` | Danh mục sản phẩm | 14 danh mục |
| `brands` | Thương hiệu | 15 thương hiệu |
| `products` | Sản phẩm | 10 sản phẩm |
| `banners` | Banner slider trang chủ | *(trống, thêm qua admin)* |
| `orders` | Đơn hàng | *(trống)* |
| `order_items` | Chi tiết đơn hàng | *(trống)* |
| `contacts` | Tin nhắn liên hệ | *(trống)* |
| `settings` | Cài đặt website | 10 cấu hình mặc định |

---

## URL quan trọng

| Trang | URL |
|-------|-----|
| Trang chủ | http://localhost/hpweb/ |
| Tìm kiếm | http://localhost/hpweb/tim-kiem?q=cpu |
| Danh mục CPU | http://localhost/hpweb/san-pham/cpu |
| Danh mục Laptop | http://localhost/hpweb/san-pham/laptop |
| Giỏ hàng | http://localhost/hpweb/gio-hang |
| Đặt hàng | http://localhost/hpweb/dat-hang |
| Liên hệ | http://localhost/hpweb/lien-he |
| Đăng nhập | http://localhost/hpweb/dang-nhap |
| Đăng ký | http://localhost/hpweb/dang-ky |
| **Admin** | http://localhost/hpweb/admin |
| Admin - Sản phẩm | http://localhost/hpweb/admin/san-pham |
| Admin - Đơn hàng | http://localhost/hpweb/admin/don-hang |
| Admin - Danh mục | http://localhost/hpweb/admin/danh-muc |
| Admin - Cài đặt | http://localhost/hpweb/admin/cai-dat |

---

## Lưu ý

- Đảm bảo **mod_rewrite** đã bật trong XAMPP (`httpd.conf`)
- Thư mục `public/images/products/` cần quyền **ghi** để upload ảnh
- Mật khẩu admin được hash bằng `bcrypt` — không thể đọc trực tiếp trong DB

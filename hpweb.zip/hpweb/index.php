<?php
declare(strict_types=1);

// ── Bootstrap ──────────────────────────────────────────────
require_once __DIR__ . '/config/app.php';
require_once __DIR__ . '/config/database.php';

// Core classes
require_once __DIR__ . '/core/Database.php';
require_once __DIR__ . '/core/Model.php';
require_once __DIR__ . '/core/Controller.php';
require_once __DIR__ . '/core/Router.php';

// Models
require_once __DIR__ . '/app/Models/CategoryModel.php';
require_once __DIR__ . '/app/Models/ProductModel.php';
require_once __DIR__ . '/app/Models/BannerModel.php';
require_once __DIR__ . '/app/Models/UserModel.php';
require_once __DIR__ . '/app/Models/OrderModel.php';
require_once __DIR__ . '/app/Models/ContactModel.php';
require_once __DIR__ . '/app/Models/SettingModel.php';

// Session
session_name(SESSION_NAME);
session_start();

// ── Router ─────────────────────────────────────────────────
$router = new Router();
require_once __DIR__ . '/routes/web.php';

$uri    = $_SERVER['REQUEST_URI'] ?? '/';
$method = $_SERVER['REQUEST_METHOD'] ?? 'GET';

$router->dispatch($uri, $method);

/* VI TÍNH NET - ADMIN JS */

// SIDEBAR TOGGLE
const sidebarToggle = document.getElementById('sidebarToggle');
const sidebar       = document.getElementById('sidebar');

sidebarToggle?.addEventListener('click', () => {
  sidebar.classList.toggle('open');
});

document.addEventListener('click', (e) => {
  if (sidebar && !sidebar.contains(e.target) && !sidebarToggle?.contains(e.target)) {
    sidebar.classList.remove('open');
  }
});

// CONFIRM DELETE
document.querySelectorAll('[data-confirm]').forEach(el => {
  el.addEventListener('click', (e) => {
    if (!confirm(el.dataset.confirm || 'Bạn có chắc không?')) e.preventDefault();
  });
});

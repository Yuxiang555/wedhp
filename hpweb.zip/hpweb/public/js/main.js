/* VI TÍNH NET - MAIN JS */

// === SLIDER ===
(function initSlider() {
  const slides = document.querySelectorAll('.slide');
  const dots   = document.querySelectorAll('.dot');
  if (!slides.length) return;

  let current = 0;
  let timer;

  function goTo(idx) {
    slides[current].classList.remove('active');
    dots[current]?.classList.remove('active');
    current = (idx + slides.length) % slides.length;
    slides[current].classList.add('active');
    dots[current]?.classList.add('active');
  }

  function next() { goTo(current + 1); }
  function prev() { goTo(current - 1); }
  function resetTimer() { clearInterval(timer); timer = setInterval(next, 5000); }

  document.querySelector('.slide-next')?.addEventListener('click', () => { next(); resetTimer(); });
  document.querySelector('.slide-prev')?.addEventListener('click', () => { prev(); resetTimer(); });
  dots.forEach((dot, i) => dot.addEventListener('click', () => { goTo(i); resetTimer(); }));

  timer = setInterval(next, 5000);
})();

// === ADD TO CART (AJAX) ===
document.querySelectorAll('.btn-add-cart').forEach(btn => {
  btn.addEventListener('click', function(e) {
    e.preventDefault();
    const productId = this.dataset.id;
    const formData  = new FormData();
    formData.append('product_id', productId);
    formData.append('quantity', '1');

    this.disabled = true;
    this.innerHTML = '<i class="fas fa-spinner fa-spin"></i>';

    fetch(window.APP_URL + '/gio-hang/them', {
      method: 'POST',
      headers: { 'X-Requested-With': 'XMLHttpRequest' },
      body: formData
    })
    .then(r => r.json())
    .then(data => {
      if (data.success) {
        // Cập nhật số lượng giỏ hàng
        const countEl = document.getElementById('cart-count');
        if (countEl) {
          countEl.textContent = data.cart_count;
          countEl.style.display = 'flex';
        }
        showToast('success', data.message || 'Đã thêm vào giỏ hàng!');
      } else {
        showToast('error', data.message || 'Có lỗi xảy ra!');
      }
    })
    .catch(() => showToast('error', 'Kết nối thất bại, vui lòng thử lại!'))
    .finally(() => {
      this.disabled = false;
      this.innerHTML = '<i class="fas fa-cart-plus"></i> Thêm vào giỏ';
    });
  });
});

// === TOAST NOTIFICATION ===
function showToast(type, message) {
  const existing = document.querySelector('.toast-container');
  if (!existing) {
    const c = document.createElement('div');
    c.className = 'toast-container';
    c.style.cssText = 'position:fixed;top:80px;right:16px;z-index:9999;display:flex;flex-direction:column;gap:8px;';
    document.body.appendChild(c);
  }

  const toast = document.createElement('div');
  const bg = type === 'success' ? '#2a9d8f' : '#e63946';
  toast.style.cssText = `background:${bg};color:#fff;padding:10px 16px;border-radius:8px;font-size:13px;
    display:flex;align-items:center;gap:8px;box-shadow:0 4px 14px rgba(0,0,0,.2);max-width:300px;
    animation:slideIn .3s ease;`;
  toast.innerHTML = `<i class="fas fa-${type === 'success' ? 'check-circle' : 'exclamation-circle'}"></i>${message}`;

  document.querySelector('.toast-container').appendChild(toast);
  setTimeout(() => { toast.style.opacity = '0'; toast.style.transition = 'opacity .3s'; setTimeout(() => toast.remove(), 300); }, 3000);
}

// Inject toast animation CSS once
if (!document.getElementById('toast-style')) {
  const s = document.createElement('style');
  s.id = 'toast-style';
  s.textContent = '@keyframes slideIn{from{transform:translateX(100%);opacity:0}to{transform:translateX(0);opacity:1}}';
  document.head.appendChild(s);
}

// === TOGGLE PASSWORD ===
document.querySelectorAll('.toggle-password').forEach(btn => {
  btn.addEventListener('click', function() {
    const input = document.getElementById(this.dataset.target);
    if (!input) return;
    const isPass = input.type === 'password';
    input.type = isPass ? 'text' : 'password';
    this.querySelector('i').className = `fas fa-eye${isPass ? '-slash' : ''}`;
  });
});

// === NAVBAR CATEGORY TOGGLE (mobile) ===
const catToggle = document.querySelector('.cat-toggle');
const catDrop   = document.querySelector('.cat-dropdown');
if (catToggle && catDrop) {
  catToggle.addEventListener('click', (e) => {
    e.stopPropagation();
    const open = catDrop.style.display === 'block';
    catDrop.style.display = open ? 'none' : 'block';
  });
  document.addEventListener('click', () => { catDrop.style.display = 'none'; });
}

// === EXPOSE APP_URL for JS ===
// Injected by layout
